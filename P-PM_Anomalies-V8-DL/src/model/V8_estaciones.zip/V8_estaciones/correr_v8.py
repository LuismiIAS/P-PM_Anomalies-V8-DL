r"""
correr_v8.py  —  el único archivo que se ejecuta.

  python correr_v8.py --gee --prueba     comprueba el acceso a Google Earth Engine (1 mes, 5 puntos)
  python correr_v8.py --gee              extrae las covariables de GEE (se puede interrumpir y retomar)
  python correr_v8.py --prueba           corrida corta del modelo para comprobar la instalación
  python correr_v8.py                    corrida completa: validación y estimaciones en los municipios
  python correr_v8.py --contaminante pm25   solo un contaminante (pm25, pm10, no2, o3)
  python correr_v8.py --copiar-nas       solo copia al NAS los resultados que ya están en resultados/
  python correr_v8.py --todo             TODO SIN INTERVENCIÓN: extracción de covariables y corrida completa del
                                         modelo, con el estado y el avance en el NAS (ESTADO.txt)

Copia al NAS: opcional. Se activa escribiendo la ruta en NAS (configuración, al inicio de este archivo),
con --nas RUTA o con la variable V8_NAS; sin ruta, todo queda en esta carpeta. Con ruta, antes de empezar
comprueba que se pueda escribir allí (si no, no arranca; --sin-nas la ignora en una corrida); durante la
corrida copia el avance (REGISTRO.txt y lo terminado) cada 10 minutos y al terminar cada contaminante; al
final copia resultados/ y gee/ (sin _cache) a una subcarpeta con fecha y hora y verifica cada archivo con
su huella SHA-256.

Antes de correr, verifica que los datos sean los aprobados por el control de calidad (huellas SHA-256 en
datos/CONTROL_CALIDAD.json). Los resultados quedan en resultados/ (o resultados_prueba/).
"""
import argparse
import hashlib
import json
import os
import platform
import shutil
import sys
import time
from datetime import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
DATOS = os.path.join(BASE, "datos")
GEE = os.path.join(BASE, "gee")
VERSION = "V8.3 (14-nov-2026): estaciones como unidad, interpolación por distancia y por uso del suelo, ajuste por uso del suelo, corregida con covariables"

# ═══ CONFIGURACIÓN: copia al NAS (opcional) ═══════════════════════════════════════════════════════════
# Vacío = sin copia: los resultados quedan solo en esta carpeta. Para copiar el avance y los resultados a un
# NAS o a otra carpeta de red, escriba aquí la ruta, por ejemplo en el equipo de Chile:
#     NAS = r"Z:\Environmental Justice\V8_estaciones"
# También se puede dar en cada corrida con --nas RUTA o con la variable de entorno V8_NAS.
# Cada corrida queda en su propia subcarpeta con fecha y hora, así que ninguna reemplaza a otra.
NAS = r""
NAS = os.environ.get("V8_NAS", NAS)
ESPEJO_CADA_MIN = 10

# Proyecto de Google Cloud con Earth Engine habilitado (el mismo de GEE_Data_Download.py)
PROYECTO_GEE = os.environ.get("V8_PROYECTO_GEE", "amazing-codex-465023-e9")


def sha256(f):
    h = hashlib.sha256()
    with open(f, "rb") as x:
        for b in iter(lambda: x.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def verificar_paquete():
    problemas = []
    cc = os.path.join(DATOS, "CONTROL_CALIDAD.json")
    if not os.path.exists(cc):
        problemas.append("falta datos/CONTROL_CALIDAD.json")
    else:
        c = json.load(open(cc, encoding="utf-8"))
        if c.get("estado") != "APROBADO":
            problemas.append("el control de calidad de los datos no dice APROBADO")
        for f, h in c.get("huellas", {}).items():
            ruta = os.path.join(DATOS, f)
            if not os.path.exists(ruta):
                problemas.append(f"falta datos/{f}")
            elif sha256(ruta) != h:
                problemas.append(f"datos/{f} cambió (¿se abrió y guardó con Excel?)")
    if "onedrive" in BASE.lower() or BASE.startswith("\\\\"):
        problemas.append("la carpeta está en OneDrive o en una unidad de red; cópiela a un disco local")
    libre = shutil.disk_usage(BASE).free / 1e9
    if libre < 10:
        problemas.append(f"hay {libre:.0f} GB libres; hacen falta al menos 10")
    if problemas:
        print("NO SE PUEDE CORRER:")
        for p in problemas:
            print("  -", p)
        sys.exit(1)
    print("Control de calidad de los datos: APROBADO")


def comprobar_nas(destino):
    """Comprueba antes de la corrida que el NAS responde y se puede escribir en él."""
    if not destino:
        print("No hay carpeta del NAS configurada: escríbala en NAS, al inicio de correr_v8.py, o use --nas RUTA.")
        sys.exit(1)
    try:
        os.makedirs(destino, exist_ok=True)
        prueba = os.path.join(destino, f".v8_prueba_escritura_{os.getpid()}")
        with open(prueba, "w") as f:
            f.write("ok")
        os.remove(prueba)
    except OSError as e:
        print(f"NO SE PUEDE CORRER: no se puede escribir en el NAS ({destino}): {e}\n"
              f"  ¿Está conectada esa unidad? Para correr sin copia: --sin-nas, o deje NAS vacío en correr_v8.py")
        sys.exit(1)
    print(f"NAS comprobado: {destino}")


def espejar(origen, destino, log=print):
    """Copia al NAS lo nuevo o cambiado de origen (copia incremental, sin la caché de GEE). Nunca detiene
    la corrida: si el NAS no responde, avisa y se reintenta en la copia siguiente."""
    if not destino or not os.path.isdir(origen):
        return False
    n = 0
    try:
        for d, sub, fs in os.walk(origen):
            sub[:] = [x for x in sub if x != "_cache"]
            for f in fs:
                o = os.path.join(d, f)
                t = os.path.join(destino, os.path.relpath(o, origen))
                so = os.stat(o)
                if os.path.exists(t):
                    st = os.stat(t)
                    if st.st_size == so.st_size and st.st_mtime >= so.st_mtime - 2:
                        continue
                os.makedirs(os.path.dirname(t), exist_ok=True)
                shutil.copy2(o, t)
                n += 1
        return True
    except OSError as e:
        log(f"  (NAS no disponible, se reintenta en la copia siguiente: {e})")
        return False


def espejo_final(origen, destino, log=print):
    """Última copia al NAS y comprobación de que cada archivo copiado sea idéntico (SHA-256). Si falla, lo
    reintenta tres veces; los resultados locales no se tocan."""
    for intento in range(1, 4):
        if espejar(origen, destino, log):
            malos = []
            for d, sub, fs in os.walk(origen):
                sub[:] = [x for x in sub if x != "_cache"]
                for f in fs:
                    o = os.path.join(d, f)
                    t = os.path.join(destino, os.path.relpath(o, origen))
                    try:
                        if sha256(o) != sha256(t):
                            malos.append(f)
                    except OSError:
                        malos.append(f)
            if not malos:
                log(f"Copiado al NAS y verificado archivo por archivo (SHA-256): {destino}")
                return True
            log(f"  {len(malos)} archivos no coinciden en el NAS (intento {intento} de 3); se copian de nuevo")
            for d, sub, fs in os.walk(destino):
                for f in fs:
                    if f in malos:
                        try:
                            os.utime(os.path.join(d, f), (0, 0))      # fuerza la copia en el intento siguiente
                        except OSError:
                            pass
        if intento < 3:
            time.sleep(60)
    log(f"NO SE PUDO COPIAR AL NAS. Los resultados están completos en {origen}. Cuando el NAS responda: "
        f"python correr_v8.py --copiar-nas")
    return False


def leer_datos(prueba=False):
    import numpy as np
    import pandas as pd
    est = pd.read_csv(os.path.join(DATOS, "estaciones.csv"), dtype={"sid": str})
    obs = pd.read_csv(os.path.join(DATOS, "observaciones_diarias.csv.gz"), dtype={"sid": str},
                      parse_dates=["fecha"])
    cab = pd.read_csv(os.path.join(GEE, "cabeceras.csv"))
    cab = cab.assign(pid="M_" + cab["municipio"].str.replace(" ", "_"), tipo="cabecera", poblacion=np.nan,
                     area_km2=np.nan)
    rej = pd.read_csv(os.path.join(GEE, "rejilla.csv")).assign(tipo="celda")
    cols = ["pid", "municipio", "tipo", "lat", "lon", "poblacion", "area_km2"]
    mun = pd.concat([cab[cols], rej[cols]], ignore_index=True)
    dinam = pd.read_csv(os.path.join(GEE, "dinamicas.csv"), dtype={"pid": str})
    dinam["date"] = pd.to_datetime(dinam["date"], format="mixed").dt.normalize()
    fijas = pd.read_csv(os.path.join(GEE, "fijas.csv"), dtype={"pid": str})
    fechas = pd.date_range("2019-01-01", "2024-12-31", freq="D")
    if prueba:
        fechas = pd.date_range("2023-01-01", "2024-12-31", freq="D")
        obs = obs[obs["fecha"].isin(fechas)]
    return obs, est, mun, dinam, fijas, list(fechas)


def puntos_gee():
    """Estaciones (todas las de datos/estaciones.csv) y polígonos de municipios."""
    import pandas as pd
    est = pd.read_csv(os.path.join(DATOS, "estaciones.csv"), dtype={"sid": str})
    return est.rename(columns={"sid": "pid"})[["pid", "lat", "lon"]]


def apartar(ruta, motivo):
    """Mueve un archivo a _to_delete (no se borra nada) y lo anota."""
    dest = os.path.join(BASE, "_to_delete", f"{datetime.now():%Y%m%d_%H%M%S}_{os.path.basename(ruta)}")
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    shutil.move(ruta, dest)
    print(f"  {os.path.basename(ruta)} apartado en {dest} ({motivo})", flush=True)


def correr_gee(prueba):
    import pandas as pd
    import v8_gee as g
    ee = g.iniciar(PROYECTO_GEE)
    print(f"GEE iniciado con el proyecto {PROYECTO_GEE}")
    destino = os.path.join(BASE, "gee_prueba" if prueba else "gee")
    os.makedirs(destino, exist_ok=True)
    cab = os.path.join(destino, "cabeceras.csv")
    if not os.path.exists(cab):
        g.cabeceras(ee, os.path.join(DATOS, "municipios.geojson"),
                    os.path.join(DATOS, "municipios_puntos_manual.csv"), cab)
    c = pd.read_csv(cab)
    rej = os.path.join(destino, "rejilla.csv")
    if os.path.exists(rej) and "punto" not in pd.read_csv(rej, nrows=1).columns:
        apartar(rej, "rejilla de la V8.2 (sin las celdas del borde)")
    if not os.path.exists(rej):
        g.rejilla(ee, os.path.join(DATOS, "municipios.geojson"), rej)
    r = pd.read_csv(rej)
    pts = pd.concat([puntos_gee(),
                     c.assign(pid="M_" + c["municipio"].str.replace(" ", "_"))[["pid", "lat", "lon"]],
                     r[["pid", "lat", "lon"]]], ignore_index=True)
    if prueba:
        n_est = len(puntos_gee())
        pts = pts.iloc[[0, 1, 2, n_est, len(pts) - 1]]
    # las covariables fijas se recalculan si cambiaron los puntos (huella de identificadores y coordenadas)
    huella = hashlib.sha256("|".join(f"{r.pid},{float(r.lat):.6f},{float(r.lon):.6f}"
                                     for r in pts.itertuples()).encode()).hexdigest()
    arch_h = os.path.join(destino, "puntos_huella.txt")
    fij = os.path.join(destino, "fijas.csv")
    if os.path.exists(fij) and (not os.path.exists(arch_h) or open(arch_h).read().strip() != huella):
        apartar(fij, "covariables fijas de otros puntos")
    if not os.path.exists(fij):
        g.extraer_fijas(ee, pts, fij)
        with open(arch_h, "w") as f:
            f.write(huella)
    g.extraer_dinamicas(ee, pts, os.path.join(destino, "dinamicas.csv"), os.path.join(destino, "_cache"), prueba)
    print(f"\nListo. Covariables en {destino}")


def firma_corrida():
    """Huella del código, los datos y las covariables: una corrida interrumpida solo se continúa si no cambió
    nada de esto."""
    h = hashlib.sha256(VERSION.encode())
    for f in [os.path.join(BASE, "v8_modelo.py"), os.path.join(DATOS, "estaciones.csv"),
              os.path.join(DATOS, "observaciones_diarias.csv.gz")] + \
             [os.path.join(GEE, x) for x in ("dinamicas.csv", "fijas.csv", "cabeceras.csv", "rejilla.csv")]:
        h.update(sha256(f).encode())
    return h.hexdigest()


def correr_modelo(contaminantes, prueba, nas=None, destino=None, continuar=False):
    if destino is None and nas:
        destino = os.path.join(nas, f"{'prueba_' if prueba else 'resultados_'}{datetime.now():%Y%m%d_%H%M}")
    ultima = [time.time()]
    import numpy as np
    import pandas as pd
    import sklearn
    import scipy
    import v8_modelo as m
    if not os.path.exists(os.path.join(GEE, "dinamicas.csv")):
        print("NO SE PUEDE CORRER: faltan las covariables de GEE. Primero: python correr_v8.py --gee")
        sys.exit(1)
    salida = os.path.join(BASE, "resultados_prueba" if prueba else "resultados")
    firma = firma_corrida()
    archivo_firma = os.path.join(salida, "FIRMA_CORRIDA.txt")
    sigue = (continuar and os.path.exists(archivo_firma)
             and open(archivo_firma, encoding="utf-8").read().strip() == firma)
    if os.path.exists(salida) and not sigue:
        dest = os.path.join(BASE, "_to_delete", f"{os.path.basename(salida)}_{datetime.now():%Y%m%d_%H%M%S}")
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.move(salida, dest)
        print(f"Resultados anteriores movidos a {dest}")
    os.makedirs(salida, exist_ok=True)
    with open(archivo_firma, "w", encoding="utf-8") as f:
        f.write(firma)
    reg = open(os.path.join(salida, "REGISTRO.txt"), "a" if sigue else "w", encoding="utf-8")

    def log(x):
        print(x, flush=True)
        reg.write(x + "\n")
        reg.flush()
        # copia del avance al NAS cada ESPEJO_CADA_MIN minutos, para revisarlo sin entrar al equipo
        if destino and time.time() - ultima[0] >= 60 * ESPEJO_CADA_MIN:
            ultima[0] = time.time()
            espejar(salida, destino, print)

    log(VERSION)
    log(f"Fecha: {datetime.now():%Y-%m-%d %H:%M}  Equipo: {platform.node()} | {platform.platform()}")
    log(f"Python {platform.python_version()} | numpy {np.__version__} | pandas {pd.__version__} | "
        f"scikit-learn {sklearn.__version__} | scipy {scipy.__version__}")
    for f in ["estaciones.csv", "observaciones_diarias.csv.gz"]:
        log(f"  datos/{f} {sha256(os.path.join(DATOS, f))}")
    for f in ["dinamicas.csv", "fijas.csv", "cabeceras.csv", "rejilla.csv"]:
        log(f"  gee/{f} {sha256(os.path.join(GEE, f))}")
    obs, est, mun, dinam, fijas, fechas = leer_datos(prueba)
    if prueba:
        m.RADIOS_AUMENTO = [0, 20, 80]
        m.HGB["max_iter"] = 100
    t0 = datetime.now()
    resumenes = {}
    if destino:
        log(f"Copia al NAS: {destino} (avance cada {ESPEJO_CADA_MIN} min y al terminar cada contaminante)")
    for p in contaminantes:
        if sigue and os.path.exists(os.path.join(salida, f"{p}_modelo.json")):
            # terminado en una corrida anterior interrumpida, con el mismo código y los mismos datos
            log(f"\n=== {p}: ya terminado en la corrida anterior; se conserva ===")
            resumenes[p] = pd.read_csv(os.path.join(salida, f"{p}_validacion_resumen.csv"), index_col=[0, 1])
            continue
        r = m.correr_contaminante(p, obs, est, mun, dinam, fijas, fechas, salida, log, prueba)
        if r is not None:
            resumenes[p] = r
        if destino:
            espejar(salida, destino, log)
    filas = []
    for p, r in resumenes.items():
        x = r.reset_index()
        x.insert(0, "contaminante", p)
        filas.append(x)
    if filas:
        pd.concat(filas).to_csv(os.path.join(salida, "VALIDACION_RESUMEN.csv"), index=False)
    log(f"\nTERMINADO en {(datetime.now() - t0).total_seconds() / 3600:.1f} h. Resultados en {salida}")
    if destino:
        espejo_final(salida, destino, log)
        if not prueba:
            espejo_final(GEE, os.path.join(destino, "gee"), log)


# ═══════════════════════════════════════════════════════════════════
# TODO SIN INTERVENCIÓN (para dejar el equipo trabajando solo)
# ═══════════════════════════════════════════════════════════════════
class Duplicar:
    """Escribe en pantalla y en un archivo a la vez, y recuerda la última línea de avance."""
    def __init__(self, consola, archivo):
        self.consola, self.archivo, self.avance, self.contaminante = consola, archivo, "", ""

    def write(self, x):
        self.consola.write(x)
        try:
            self.archivo.write(x)
            self.archivo.flush()
        except (OSError, ValueError):
            pass
        for linea in x.splitlines():
            if linea.startswith("=== "):
                self.contaminante = linea.strip("= ").strip()
            if any(k in linea for k in ("consultas", "pliegue", "===", "fijas:", "Earth Engine pide esperar",
                                        "TERMINADO", "Listo.")):
                self.avance = linea.strip()

    def flush(self):
        self.consola.flush()


def mantener_despierto():
    """En Windows, evita que el equipo se suspenda mientras corre (no evita reinicios de Windows Update)."""
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001)
            print("El equipo no se suspenderá mientras dure la corrida.")
        except Exception as e:
            print(f"(no se pudo evitar la suspensión del equipo: {e})")


def correr_todo(nas):
    import threading
    import traceback
    destino = None
    if nas:
        comprobar_nas(nas)
        destino = os.path.join(nas, f"corrida_{datetime.now():%Y%m%d_%H%M}")
        os.makedirs(destino, exist_ok=True)
    registro = open(os.path.join(BASE, "REGISTRO_TODO.txt"), "a", encoding="utf-8")
    sys.stdout = Duplicar(sys.__stdout__, registro)
    sys.stderr = Duplicar(sys.__stderr__, registro)
    inicio = datetime.now()
    etapa = ["Comprobaciones"]

    def estado(final=None):
        cont = f"Contaminante en curso: {sys.stdout.contaminante}\n" if sys.stdout.contaminante and not final else ""
        texto = (f"{final or etapa[0]}\n\n{cont}Último avance: {sys.stdout.avance}\n"
                 f"Actualizado: {datetime.now():%Y-%m-%d %H:%M} (hora del equipo)\n"
                 f"Inicio: {inicio:%Y-%m-%d %H:%M}\nEquipo: {platform.node()}\n{VERSION}\n\n"
                 f"El registro completo está en REGISTRO_TODO.txt; los resultados, en resultados/.\n")
        try:
            with open(os.path.join(BASE, "ESTADO.txt"), "w", encoding="utf-8") as f:
                f.write(texto)
            if destino:
                for x in ("ESTADO.txt", "REGISTRO_TODO.txt"):
                    shutil.copy2(os.path.join(BASE, x), os.path.join(destino, x))
        except OSError as e:
            print(f"  (NAS no disponible para el estado, se reintenta: {e})", file=sys.__stdout__)

    parar = threading.Event()

    def cada_rato():
        while not parar.wait(60 * ESPEJO_CADA_MIN):
            estado()

    threading.Thread(target=cada_rato, daemon=True).start()
    mantener_despierto()
    if destino:
        print(f"Estado y avance en el NAS: {destino}\\ESTADO.txt (cada {ESPEJO_CADA_MIN} min)")
    else:
        print(f"Sin NAS configurado: el estado (ESTADO.txt), el registro y los resultados quedan en {BASE}")
    try:
        # etapa 1: covariables (si se interrumpe o falla, se reintenta; el caché conserva lo ya extraído)
        for ronda in range(1, 9):
            etapa[0] = f"EN CURSO. Etapa 1 de 2: extracción de covariables de Earth Engine (ronda {ronda})"
            estado()
            try:
                correr_gee(False)
                break
            except (SystemExit, Exception) as e:
                if ronda == 8:
                    raise RuntimeError(f"la extracción de covariables falló 8 veces; último error: {e}")
                motivo = "con un error" if isinstance(e, SystemExit) else f"({str(e)[:200]})"
                print(f"\nLa extracción se detuvo {motivo}. Se reintenta en 30 min (ronda {ronda + 1} de 8); "
                      f"lo ya extraído se conserva.", flush=True)
                etapa[0] = f"EN CURSO. Etapa 1 de 2: extracción en pausa; reintento en 30 min (ronda {ronda + 1})"
                estado()
                time.sleep(1800)
        # etapa 2: modelo completo
        etapa[0] = "EN CURSO. Etapa 2 de 2: modelo (validación y estimaciones en los municipios)"
        estado()
        correr_modelo(["pm25", "pm10", "no2", "o3"], False, nas,
                      destino=os.path.join(destino, "resultados") if destino else None,
                      continuar=True)
        parar.set()
        estado(f"TERMINADO el {datetime.now():%Y-%m-%d %H:%M} (hora del equipo), en "
               f"{(datetime.now() - inicio).total_seconds() / 3600:.1f} h. Resultados en resultados/.")
    except BaseException as e:
        parar.set()
        print("\n" + traceback.format_exc(), flush=True)
        estado(f"FALLÓ: {str(e)[:500]}\n\nSi se vuelve a correr python correr_v8.py --todo, sigue donde quedó "
               f"(las covariables ya extraídas y los contaminantes ya terminados se conservan).")
        sys.exit(1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gee", action="store_true")
    ap.add_argument("--prueba", action="store_true")
    ap.add_argument("--contaminante", choices=["pm25", "pm10", "no2", "o3"])
    ap.add_argument("--nas", default=NAS, help="carpeta de destino en el NAS (por defecto, la de la configuración)")
    ap.add_argument("--sin-nas", action="store_true", help="no copiar al NAS aunque esté configurado")
    ap.add_argument("--copiar-nas", action="store_true", help="solo copiar al NAS los resultados existentes")
    ap.add_argument("--todo", action="store_true", help="covariables y modelo completo, sin intervención")
    a = ap.parse_args()
    print(VERSION)
    if a.copiar_nas:
        comprobar_nas(a.nas)
        salida = os.path.join(BASE, "resultados")
        if not os.path.isdir(salida):
            print(f"No hay resultados en {salida}")
            sys.exit(1)
        destino = os.path.join(a.nas, f"resultados_{datetime.fromtimestamp(os.path.getmtime(salida)):%Y%m%d_%H%M}")
        ok = espejo_final(salida, destino) and espejo_final(GEE, os.path.join(destino, "gee"))
        sys.exit(0 if ok else 1)
    verificar_paquete()
    nas = None if a.sin_nas or not a.nas else a.nas
    if not nas:
        print("Sin copia al NAS: los resultados quedan en esta carpeta.")
    if a.todo:
        correr_todo(nas)
    elif a.gee:
        correr_gee(a.prueba)
    else:
        # si hay NAS, se comprueba antes de empezar, también en la prueba (así se verifica antes de la corrida larga)
        if nas:
            comprobar_nas(nas)
        correr_modelo([a.contaminante] if a.contaminante else ["pm25", "pm10", "no2", "o3"], a.prueba, nas)


if __name__ == "__main__":
    main()
