"""
v8_modelo.py

Modelo V8: la estación como unidad. Para cada contaminante y cada día estima el valor en un lugar sin
estación a partir de lo que miden ese día las estaciones vecinas (inverso de la distancia al cuadrado) y
corrige esa interpolación con lo que diferencia al lugar de sus vecinas (meteorología, satélite, altitud,
población, superficie construida, luces nocturnas, coberturas). El aprendiz es un modelo de árboles con
gradiente (HistGradientBoosting), que acepta los faltantes del satélite sin rellenarlos.

Decisiones de diseño (cada una responde a una limitación de la V7.1)
  1. Unidad: la estación, con todas las que miden cada contaminante (no solo las que miden los cuatro).
  2. Coordenadas: entran por las distancias (pesos 1/d², distancia a la vecina, vecinas en 50 km) y por
     las diferencias de covariables entre el lugar y sus vecinas. Latitud y longitud no entran como
     variables, porque un modelo de árboles las usaría para memorizar lugares y no se transfiere.
  3. Aumento por distancia: cada estación de entrenamiento se representa también como si sus vecinas
     estuvieran a 5, 10, 20, 40, 80 o 160 km (se retiran las cercanas). Así el modelo aprende cómo pierde
     información la interpolación con la distancia, que es la situación de los municipios.
  4. Hiperparámetros fijos, declarados antes de evaluar (no se eligen con los pliegues de evaluación;
     así no hace falta una validación anidada).
  5. Validación con pliegues kNNDM (Linnenbrink et al., 2024): reparten las estaciones de modo que la
     distancia de cada estación de prueba a la de entrenamiento más cercana reproduzca la distancia de los
     municipios a su estación más cercana. Hay dos: uno con las celdas habitadas de la rejilla (para la
     media poblacional) y otro solo con las cabeceras (para el valor en la cabecera, el enfoque anterior);
     cada estimación lleva el error y los intervalos del diseño que reproduce sus distancias. Se agregan
     dejar un departamento fuera y 10 pliegues al azar para medir el error en todo el rango de distancias.
  6. Área de aplicabilidad (Meyer y Pebesma, 2021): índice de disimilitud de cada municipio frente a las
     estaciones en el espacio de covariables ponderado por importancia.
  7. Intervalos conformes por clase de distancia, calibrados con los residuos de la validación, y
     errores medidos de la media anual y de los días sobre el límite, para las métricas del artículo.
  8. Exposición de todo el municipio, no solo de la cabecera: el modelo estima cada celda de una rejilla
     que cubre todo el polígono municipal, con las celdas del borde (de 1.3 a 3 km de lado; cada celda se
     estima en su píxel de 100 m con más población) y
     las agrega con la población de cada celda (GHSL 2020). Así se obtiene la media ponderada por
     población, que es la exposición de la gente, la media territorial y la fracción de la población que
     vive en celdas sobre los valores de referencia anuales. Los intervalos de las medias municipales usan
     el error medido en estaciones individuales, que es una cota conservadora: al promediar celdas parte
     del error se compensa, pero no hay una red densa dentro de los municipios para medir cuánto.

  9. Ponderación por uso del suelo: además del peso 1/d², cada vecina recibe un factor de similitud de uso
     del suelo con el lugar, exp(-½ (s/h)²), con coberturas de ESA WorldCover, población y luces
     (VARS_SUELO). Responde a que la mayoría de las estaciones son urbanas y la mayoría de las celdas de los
     municipios no: con el peso por distancia solo, la base de la interpolación es urbana. El ancho h es la
     mediana de s entre estaciones, fijado antes de evaluar.
 10. Seis métodos en los mismos pliegues (METODOS): inverso de la distancia, inverso de la distancia con
     similitud de suelo, inverso de la distancia con ajuste por suelo (punto 11), híbrido, híbrido con
     suelo y la media geométrica de los dos con similitud de suelo, con pesos iguales fijos.
     No se buscan combinaciones abiertas. La elección sigue una regla declarada (seleccion_metodo) que
     prefiere el método más simple salvo que uno más complejo reduzca el error en al menos MEJORA_MINIMA
     puntos aun sin cualquier grupo espacial, con un intervalo de remuestreo por grupos que excluya el
     cero, y, en los métodos con uso del suelo, que superen a su placebo o a la prueba de permutación;
     todos los métodos quedan en los resultados.

 11. Ajuste por uso del suelo (idw_ajuste_suelo): el residuo logarítmico del inverso de la distancia se
     explica con las diferencias de uso del suelo entre el lugar y sus vecinas mediante una regresión ridge
     lineal, ajustada dentro de cada pliegue con las estaciones de entrenamiento. La penalización se elige
     con validación interna por grupos espaciales (ALFAS_RIDGE), incluida la opción de no corregir. Sus
     coeficientes, con signo y magnitud, son los coeficientes de ponderación del uso del suelo, y se
     reportan con un intervalo por remuestreo de grupos espaciales. Que el signo se repita entre pliegues
     no es evidencia, porque los pliegues comparten la mayoría de las estaciones. La importancia de variables no sirve como coeficiente
     (no tiene signo ni unidades, y las variables correlacionadas se la reparten), así que se usa como
     diagnóstico.
 12. Diagnóstico del error según el uso del suelo: correlación entre el error fuera de pliegue de cada
     estación y su uso del suelo, error por clase de urbanización con la fracción de la población de los
     municipios en cada clase, e importancia por permutación de grupos de variables en todos los pliegues.

Referencias de comparación en los mismos pliegues: estación más cercana y modelo sin vecinas (solo
covariables).
"""
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import fcluster, linkage
from scipy.stats import wasserstein_distance
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.inspection import permutation_importance

# Hilos para construir las filas (cada estación o punto es independiente). El modelo de árboles ya usa todos
# los núcleos por su cuenta (OpenMP); esta parte, que antes era de un solo núcleo, era cerca de la mitad del
# tiempo de cada pliegue en un equipo con muchos núcleos.
HILOS = max(1, min(32, os.cpu_count() or 1))


def mapa(f, tareas):
    """Aplica f a cada tarea con HILOS hilos y devuelve los resultados en el mismo orden."""
    if HILOS == 1 or len(tareas) < 2:
        return [f(t) for t in tareas]
    with ThreadPoolExecutor(HILOS) as ex:
        return list(ex.map(f, tareas))


CONTAMINANTES = ["pm25", "pm10", "no2", "o3"]
NOMBRE = {"pm25": "PM2.5 (24 h)", "pm10": "PM10 (24 h)", "no2": "NO2 (24 h)", "o3": "O3 (MDA8)"}
LIMITE_2254 = {"pm25": 37.0, "pm10": 75.0, "no2": None, "o3": 100.0}   # Res. 2254 de 2017, µg/m³
GUIA_OMS = {"pm25": 15.0, "pm10": 45.0, "no2": 25.0, "o3": 100.0}      # OMS 2021, 24 h y 8 h
ANUAL_2254 = {"pm25": 25.0, "pm10": 50.0, "no2": 60.0, "o3": None}     # Res. 2254 de 2017, anual
ANUAL_OMS = {"pm25": 5.0, "pm10": 15.0, "no2": 10.0, "o3": None}       # OMS 2021, anual
MIN_DIAS = 274
PISO = 0.5                                       # µg/m³ antes del logaritmo
RADIOS_AUMENTO = [0, 5, 10, 20, 40, 80, 160]     # km
FRACCION_AUMENTO = 0.35                           # fracción de días que se conserva en cada radio
K_PLIEGUES = 10
CLASES_KM = [0, 5, 15, 30, 60, 120, 1e9]
ETIQ_CLASES = ["0-5", "5-15", "15-30", "30-60", "60-120", ">120"]
SEMILLA = 42
HGB = dict(loss="squared_error", learning_rate=0.05, max_iter=800, max_leaf_nodes=31, min_samples_leaf=200,
           l2_regularization=1.0, early_stopping=True, validation_fraction=0.1, n_iter_no_change=30,
           random_state=SEMILLA)
COVS_DELTA = ["no2_tropomi", "aod_maiac", "pm25_merra2", "co_tropomi", "t2m", "blh_media", "tp", "u10", "v10",
              "altitud", "poblacion_1km", "poblacion_5km", "construido_m2_1km", "luces_1km",
              "frac_construido_1km", "frac_arboles_5km", "frac_cultivos_5km"]
# Similitud de uso del suelo entre el lugar y cada estación vecina: coberturas de ESA WorldCover e intensidad de
# ocupación (población y luces, en logaritmo), estandarizadas con las estaciones. El peso de cada vecina es
# (1/d²) x exp(-½ (s/h)²), con s la distancia euclidiana en ese espacio y h la mediana de s entre pares de
# estaciones (regla fijada antes de evaluar; no se ajusta con los pliegues).
VARS_SUELO = ["frac_construido_1km", "frac_construido_5km", "frac_arboles_5km", "frac_arbustos_5km",
              "frac_pastos_5km", "frac_cultivos_5km", "poblacion_5km", "luces_1km"]
LOG_SUELO = {"poblacion_5km", "luces_1km"}
COLS_SUELO = {"idw2_suelo", "idw_suelo_sd", "n_similares150"}       # variables que solo ve el híbrido con suelo
COLS_PLACEBO = {"idw2_placebo"}                                     # control; ningún modelo la usa
# Ajuste del inverso de la distancia por uso del suelo: el residuo logarítmico de la interpolación se explica
# con las diferencias de uso del suelo entre el lugar y sus vecinas (du_*, estandarizadas) mediante una
# regresión ridge lineal, ajustada solo con las estaciones de entrenamiento de cada pliegue. Sus coeficientes
# son los coeficientes de ponderación del uso del suelo y se reportan con su variación entre pliegues.
# La penalización se elige dentro de cada pliegue con validación interna por grupos espaciales de las
# estaciones de entrenamiento, entre estos valores y la opción de no corregir (coeficientes en cero).
ALFAS_RIDGE = [0.1, 1.0, 10.0, 100.0, 1000.0, 1e4]   # en unidades de estaciones (cada estación pesa 1)
MEJORA_MINIMA = 1.0      # puntos de NMAE: una mejora menor no se considera relevante para el artículo
# Métodos que estiman los municipios, en orden de complejidad (la regla de elección prefiere el más simple)
METODOS = ["idw", "idw_suelo", "idw_ajuste_suelo", "hibrido", "hibrido_suelo", "promedio"]
CON_PLACEBO = {"idw_suelo", "hibrido_suelo", "promedio"}            # usan la ponderación por similitud
DESCRIPCION = {"idw": "inverso de la distancia al cuadrado",
               "idw_suelo": "inverso de la distancia ponderado por similitud de uso del suelo",
               "idw_ajuste_suelo": "inverso de la distancia corregido con coeficientes de uso del suelo (ridge)",
               "hibrido": "híbrido (árboles) con la interpolación por distancia",
               "hibrido_suelo": "híbrido con la interpolación por distancia y la ponderada por uso del suelo",
               "promedio": "media geométrica de idw_suelo e hibrido_suelo, con pesos iguales fijos"}
N_PERMUTACIONES = 19     # prueba de permutación del ajuste por suelo: p mínimo 1/20 = 0.05
GRUPO_KM = 20            # estaciones a menos de 20 km forman un grupo para el remuestreo de la elección
N_REMUESTREOS = 2000


# ═══════════════════════════════════════════════════════════════════
# GEOMETRÍA
# ═══════════════════════════════════════════════════════════════════
def km(lat1, lon1, lat2, lon2):
    lat1, lon1, lat2, lon2 = map(np.radians, (lat1, lon1, lat2, lon2))
    a = np.sin((lat2 - lat1) / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2
    return 6371.0 * 2 * np.arcsin(np.sqrt(a))


def matriz_km(a, b):
    return km(a["lat"].values[:, None], a["lon"].values[:, None], b["lat"].values[None], b["lon"].values[None])


def xy_km(t):
    lat0 = np.radians(t["lat"].mean())
    return np.c_[6371 * np.radians(t["lon"].values) * np.cos(lat0), 6371 * np.radians(t["lat"].values)]


# ═══════════════════════════════════════════════════════════════════
# PLIEGUES
# ═══════════════════════════════════════════════════════════════════
def nnd_prueba(folds, D):
    """Distancia de cada estación a la estación más cercana de los otros pliegues."""
    out = np.empty(len(folds))
    for i, f in enumerate(folds):
        out[i] = D[i, folds != f].min()
    return out


def knndm(est, mun, k=K_PLIEGUES, semilla=SEMILLA):
    """k-fold NNDM (Linnenbrink et al., 2024): agrupamiento jerárquico de las estaciones en q grupos,
    repartidos en k pliegues; se elige la partición cuya distribución de distancias prueba-entrenamiento
    más se parece (distancia de Wasserstein) a la de municipios-estaciones."""
    D = matriz_km(est, est)
    np.fill_diagonal(D, np.inf)
    g_pred = matriz_km(mun, est).min(axis=1)
    rng = np.random.default_rng(semilla)
    mejores = []
    al_azar = rng.permutation(np.arange(len(est)) % k)
    mejores.append((wasserstein_distance(nnd_prueba(al_azar, D), g_pred), "azar", al_azar))
    Z = linkage(xy_km(est), method="ward")
    for q in sorted(set(np.linspace(k, max(k, len(est) - 1), 40).astype(int))):
        grupos = fcluster(Z, t=q, criterion="maxclust")
        tam = pd.Series(grupos).value_counts()
        carga = np.zeros(k)
        asign = {}
        for gr in tam.index:                       # el grupo más grande al pliegue con menos estaciones
            f = int(np.argmin(carga))
            asign[gr] = f
            carga[f] += tam[gr]
        folds = np.array([asign[g] for g in grupos])
        if len(set(folds)) < k:
            continue
        mejores.append((wasserstein_distance(nnd_prueba(folds, D), g_pred), f"q={q}", folds))
    w, desc, folds = min(mejores, key=lambda x: x[0])
    return folds, {"W": round(float(w), 2), "particion": desc,
                   "nnd_municipios_mediana_km": round(float(np.median(g_pred)), 1),
                   "nnd_prueba_mediana_km": round(float(np.median(nnd_prueba(folds, D))), 1)}


# ═══════════════════════════════════════════════════════════════════
# VARIABLES
# ═══════════════════════════════════════════════════════════════════
class Datos:
    """Arreglos día x lugar para un contaminante."""

    def __init__(self, obs, est, mun, dinam, fijas, contaminante, fechas):
        self.p = contaminante
        self.fechas = fechas
        o = obs[obs["contaminante"] == contaminante]
        cuenta = o.groupby("sid").size()
        validas = cuenta[cuenta >= MIN_DIAS].index
        self.est = est[est["sid"].isin(validas)].reset_index(drop=True)
        Y = o.pivot_table(index="fecha", columns="sid", values="valor").reindex(index=fechas,
                                                                                 columns=self.est["sid"])
        self.Y = np.log(np.maximum(Y.values, PISO))                                   # T x S
        self.mun = mun.reset_index(drop=True)
        self.D = matriz_km(self.est, self.est)                                        # S x S
        self.grupos = grupos_espaciales(self.est)                                     # grupos a 20 km
        self.DM = matriz_km(self.mun, self.est)                                       # M x S
        # covariables dinámicas y fijas, por lugar
        self.dyn_cols = [c for c in dinam.columns if c not in ("pid", "date")]
        self.fix_cols = [c for c in fijas.columns if c != "pid"]
        pids = list(self.est["sid"]) + list(self.mun["pid"])
        dd = dinam.set_index(["date", "pid"])
        self.C = {}
        for c in self.dyn_cols:
            m = dd[c].unstack("pid").reindex(index=fechas, columns=pids)
            self.C[c] = m.values.astype("float32")                                     # T x (S+M)
        vacias = [c for c in self.dyn_cols if np.isnan(self.C[c][:, :len(self.est)]).all()]
        if len(vacias) == len(self.dyn_cols):
            raise ValueError("Las covariables dinámicas no coinciden con las estaciones o las fechas "
                             "(todas faltantes): revise gee/dinamicas.csv")
        nulas_m = [c for c in self.dyn_cols if np.isnan(self.C[c][:, len(self.est):]).all()]
        if len(nulas_m) == len(self.dyn_cols):
            raise ValueError("Las covariables dinámicas faltan en todos los puntos de los municipios: "
                             "revise gee/dinamicas.csv")
        ff = fijas.set_index("pid").reindex(pids)
        self.F = ff[self.fix_cols].astype("float32")                                   # (S+M) x F
        self.deltas = [c for c in COVS_DELTA if c in self.dyn_cols or c in self.fix_cols]
        # espacio de uso del suelo (fijo por lugar) y ancho de banda de la similitud
        self.vars_suelo = [c for c in VARS_SUELO if c in self.fix_cols]
        S = len(self.est)
        if self.vars_suelo:
            A = np.column_stack([np.log1p(np.maximum(ff[c].values.astype(float), 0)) if c in LOG_SUELO
                                 else ff[c].values.astype(float) for c in self.vars_suelo])
            mu, sd = np.nanmean(A[:S], 0), np.nanstd(A[:S], 0)
            sd[~(sd > 0)] = 1
            self.U = np.nan_to_num((A - mu) / sd)                                      # (S+M) x u
            self.mu_suelo, self.sd_suelo = mu, sd
            Ue = self.U[:S]
            s = np.sqrt(((Ue[:, None, :] - Ue[None, :, :]) ** 2).sum(-1))[np.triu_indices(S, 1)]
            self.h_suelo = float(np.median(s)) if len(s) and np.median(s) > 0 else 1.0
        else:
            self.U = np.zeros((S + len(self.mun), 1))
            self.h_suelo = 1.0
            self.mu_suelo, self.sd_suelo = np.zeros(1), np.ones(1)
        # placebo: el mismo uso del suelo, permutado entre estaciones. Si la ponderación por suelo no supera a
        # su placebo, su ganancia no viene del uso del suelo sino de reponderar las vecinas
        self.U_placebo = self.U.copy()
        self.U_placebo[:S] = self.U[np.random.default_rng(SEMILLA + 7).permutation(S)]
        rp = np.random.default_rng(SEMILLA + 11)
        self.perms = [rp.permutation(S) for _ in range(N_PERMUTACIONES)]
        self._u_apilado = {}
        doy = pd.DatetimeIndex(fechas).dayofyear.values
        self.cal = np.c_[np.sin(2 * np.pi * doy / 365.25), np.cos(2 * np.pi * doy / 365.25),
                         pd.DatetimeIndex(fechas).dayofweek.values].astype("float32")

    def U_apilado(self, n_perm):
        """U real y n_perm versiones con el uso del suelo permutado entre estaciones: (S+M) x u x (1+n_perm)."""
        if n_perm not in self._u_apilado:
            S = len(self.est)
            capas = [self.U]
            for k in range(n_perm):
                Up = self.U.copy()
                Up[:S] = self.U[self.perms[k]]
                capas.append(Up)
            self._u_apilado[n_perm] = np.stack(capas, axis=2)
        return self._u_apilado[n_perm]

    def cov_lugar(self, c, j):
        """Covariable c en el lugar j (índice en est + mun), serie T o constante."""
        if c in self.C:
            return self.C[c][:, j]
        return np.full(len(self.fechas), self.F[c].values[j], dtype="float32")

    def cov_vecinas(self, c, cols):
        if c in self.C:
            return self.C[c][:, cols]
        return np.broadcast_to(self.F[c].values[cols][None, :], (len(self.fechas), len(cols)))

    def variables(self, j, dist, vecinas, con_vecinas=True):
        """Tabla T x variables para el lugar j (índice global), con las estaciones `vecinas` (índices en est)
        a las distancias `dist` (km)."""
        T = len(self.fechas)
        cols = {}
        if con_vecinas and len(vecinas):
            Yv = self.Y[:, vecinas]
            m = np.isfinite(Yv)
            d = np.maximum(dist[vecinas], 1.0)
            w = m * (1.0 / d ** 2)[None, :]
            sw = w.sum(1)
            Yz = np.where(m, Yv, 0.0)
            idw = np.where(sw > 0, (w * Yz).sum(1) / np.where(sw > 0, sw, 1), np.nan)
            w1 = m * (1.0 / d)[None, :]
            s1 = w1.sum(1)
            cols["idw2"] = idw
            cols["idw1"] = np.where(s1 > 0, (w1 * Yz).sum(1) / np.where(s1 > 0, s1, 1), np.nan)
            dm = np.where(m, d[None, :], np.inf)
            k = dm.argmin(1)
            cols["dmin"] = np.where(np.isfinite(dm.min(1)), dm.min(1), np.nan)
            cols["vecina"] = np.where(np.isfinite(dm.min(1)), Yz[np.arange(T), k], np.nan)
            cols["n50"] = (m & (d[None, :] <= 50)).sum(1)
            cols["n150"] = (m & (d[None, :] <= 150)).sum(1)
            var = np.where(sw > 0, (w * (Yz - np.nan_to_num(idw)[:, None]) ** 2).sum(1) / np.where(sw > 0, sw, 1),
                           np.nan)
            cols["idw_sd"] = np.sqrt(var)
            # interpolación ponderada por distancia y similitud de uso del suelo
            s_suelo = np.sqrt(((self.U[vecinas] - self.U[j][None, :]) ** 2).sum(-1))
            sim = np.exp(-0.5 * (s_suelo / self.h_suelo) ** 2)
            ws = w * sim[None, :]
            ss = ws.sum(1)
            idws = np.where(ss > 0, (ws * Yz).sum(1) / np.where(ss > 0, ss, 1), np.nan)
            cols["idw2_suelo"] = idws
            vs = np.where(ss > 0, (ws * (Yz - np.nan_to_num(idws)[:, None]) ** 2).sum(1) / np.where(ss > 0, ss, 1),
                          np.nan)
            cols["idw_suelo_sd"] = np.sqrt(vs)
            cols["n_similares150"] = (m & (d[None, :] <= 150) & (sim[None, :] >= 0.5)).sum(1)
            s_pl = np.sqrt(((self.U_placebo[vecinas] - self.U_placebo[j][None, :]) ** 2).sum(-1))
            wp = w * np.exp(-0.5 * (s_pl / self.h_suelo) ** 2)[None, :]
            sp = wp.sum(1)
            cols["idw2_placebo"] = np.where(sp > 0, (wp * Yz).sum(1) / np.where(sp > 0, sp, 1), np.nan)
            # diferencias de uso del suelo entre el lugar y la media de sus vecinas (pesos 1/d² del día)
            Uv = self.U[vecinas]                                                         # V x u
            media_u = np.where(sw[:, None] > 0, (w @ Uv) / np.where(sw > 0, sw, 1)[:, None], np.nan)
            for k, c in enumerate(self.vars_suelo):
                cols[f"du_{c}"] = self.U[j, k] - media_u[:, k]
            gidx = vecinas                                                     # índices globales = est
            for c in self.deltas:
                cv = self.cov_vecinas(c, gidx)
                mc = m & np.isfinite(cv)
                wc = mc * (1.0 / d ** 2)[None, :]
                sc = wc.sum(1)
                media = np.where(sc > 0, (wc * np.where(mc, cv, 0)).sum(1) / np.where(sc > 0, sc, 1), np.nan)
                cols[f"delta_{c}"] = self.cov_lugar(c, j) - media
        for c in self.dyn_cols:
            cols[c] = self.cov_lugar(c, j)
        for c in self.fix_cols:
            cols[c] = np.full(T, self.F[c].values[j], dtype="float32")
        cols["doy_sin"], cols["doy_cos"], cols["dia_semana"] = self.cal.T
        return pd.DataFrame(cols)

    # ── filas de entrenamiento y de prueba ──
    def filas_entrenamiento(self, train, rng, con_vecinas=True):
        # las semillas del submuestreo se sacan antes, en el mismo orden de siempre, para que el resultado no
        # dependa del número de hilos
        tareas = []
        for s in train:
            radios = RADIOS_AUMENTO if con_vecinas else [0]
            for r in radios:
                vec = np.array([t for t in train if t != s and self.D[s, t] > max(r, 0.5)])
                if con_vecinas and len(vec) == 0:
                    continue
                tareas.append((s, r, vec, int(rng.integers(1e9)) if con_vecinas else None))

        def hacer(tarea):
            s, r, vec, semilla = tarea
            X = self.variables(s, self.D[s], vec, con_vecinas)
            X["y"] = self.Y[:, s]
            X["sid_idx"] = s
            X["radio"] = r
            X["t"] = np.arange(len(self.fechas))
            X = X[np.isfinite(X["y"].values)]
            if semilla is not None:
                X = X.sample(frac=FRACCION_AUMENTO, random_state=semilla)
            return X
        return pd.concat(mapa(hacer, tareas), ignore_index=True)

    def filas_prueba(self, test, train, con_vecinas=True):
        train = np.array(train)

        def hacer(s):
            vec = train[self.D[s, train] > 0.5]
            X = self.variables(s, self.D[s], vec, con_vecinas)
            X["y"] = self.Y[:, s]
            X["sid_idx"] = s
            X["t"] = np.arange(len(self.fechas))
            return X[np.isfinite(X["y"].values)]
        return pd.concat(mapa(hacer, list(test)), ignore_index=True)

    def filas_municipio(self, i):
        j = len(self.est) + i
        vec = np.arange(len(self.est))
        X = self.variables(j, self.DM[i], vec, True)
        X["t"] = np.arange(len(self.fechas))
        return X


NO_X = {"y", "sid_idx", "radio", "t"}


def ajustar(F, semilla=SEMILLA, excluir=()):
    # las du_* son solo del ajuste lineal; los híbridos tienen sus propias diferencias (delta_*)
    X = F[[c for c in F.columns if c not in NO_X and c not in excluir and not c.startswith("du_")]]
    # una variable sin ningún valor o con un solo valor en el entrenamiento no aporta (y el agrupamiento en
    # intervalos del modelo de árboles falla con ella): se deja fuera y queda anotada en el modelo
    utiles = [c for c in X.columns if X[c].notna().any() and X[c].nunique(dropna=True) > 1]
    X = X[utiles]
    m = HistGradientBoostingRegressor(**{**HGB, "random_state": semilla}).fit(X, F["y"])
    res = F["y"].values - m.predict(X)
    m.smear_ = duan(res, F["dmin"].values if "dmin" in F else None)
    m.cols_ = list(X.columns)
    return m


def duan(res, dmin=None):
    """Corrección de Duan al volver de logaritmos, media de exp(residuo), por clase de distancia a la
    estación vecina cuando la hay (la dispersión del residuo crece con la distancia)."""
    ok = np.isfinite(res)
    glob = float(np.mean(np.exp(res[ok])))
    if dmin is None:
        return {"_todas": glob}
    cl = clase_km(dmin)
    s = pd.Series(np.exp(res)).where(ok).groupby(np.asarray(cl.astype(str))).mean()
    out = {k: float(v) for k, v in s.items() if np.isfinite(v)}
    out["_todas"] = glob
    return out


def factor(smear, dmin=None, n=None):
    if dmin is None or len(smear) == 1:
        return np.full(n if n is not None else len(dmin), smear["_todas"])
    cl = np.asarray(clase_km(dmin).astype(str))
    return np.array([smear.get(c, smear["_todas"]) for c in cl])


def predecir(m, F):
    return m.predict(F[m.cols_])


def ajustar_metodos(F, dat, train, n_perm=0):
    """Los dos híbridos (sin y con las variables de uso del suelo), la corrección de Duan de las
    interpolaciones y el ajuste por uso del suelo (con n_perm repeticiones con el uso del suelo permutado
    entre estaciones, para la prueba de permutación)."""
    d = F["dmin"].values
    St = estadisticas_ajuste(dat, train, n_perm)
    ajustes = [ajuste_desde_sumas(St, dat.vars_suelo, k) for k in range(n_perm + 1)] if St else [None]
    return {"hibrido": ajustar(F, excluir=COLS_SUELO | COLS_PLACEBO),
            "hibrido_suelo": ajustar(F, excluir=COLS_PLACEBO),
            "smear_idw": duan((F["y"] - F["idw2"]).values, d),
            "smear_idw_suelo": duan((F["y"] - F["idw2_suelo"]).values, d),
            "smear_idw_placebo": duan((F["y"] - F["idw2_placebo"]).values, d),
            "ridge": ajustes[0], "ridge_perm": ajustes[1:], "cols_du": [f"du_{c}" for c in dat.vars_suelo],
            "sumas_ajuste": St}


# ── ajuste por uso del suelo con sumas suficientes por grupo espacial ──
# El residuo r = y - idw2 y las diferencias de uso del suelo X = U_lugar - media ponderada de U de las vecinas
# se acumulan por estación (Σ1, ΣX, ΣXX', Σr, ΣXr, Σr²) con todos los días y radios del aumento, y cada
# estación se reescala para pesar 1. Con esas sumas, sumadas por grupo espacial, la regresión ridge, su
# validación interna dejando grupos fuera, el remuestreo de los coeficientes y las repeticiones con el uso
# del suelo permutado se calculan sin volver a recorrer los días.
def estadisticas_ajuste(dat, train, n_perm=0):
    if not dat.vars_suelo:
        return None
    Ust = dat.U_apilado(n_perm)                                   # (S+M) x u x P
    _, u, P = Ust.shape
    train = np.asarray(train)
    por_grupo = {}
    for s in train:
        acc = None
        n_s = 0
        for r in RADIOS_AUMENTO:
            vec = np.array([t for t in train if t != s and dat.D[s, t] > max(r, 0.5)])
            if len(vec) == 0:
                continue
            y = dat.Y[:, s]
            Yv = dat.Y[:, vec]
            m = np.isfinite(Yv)
            w = m * (1.0 / np.maximum(dat.D[s, vec], 1.0) ** 2)[None, :]
            sw = w.sum(1)
            ok = np.isfinite(y) & (sw > 0)
            if not ok.any():
                continue
            Wn = w[ok] / sw[ok, None]
            res = y[ok] - (Wn * np.where(m[ok], Yv[ok], 0.0)).sum(1)
            X = Ust[s][None] - (Wn @ Ust[vec].reshape(len(vec), u * P)).reshape(-1, u, P)
            a = {"n": float(ok.sum()), "Sx": X.sum(0), "Sxx": np.einsum("nap,nbp->abp", X, X),
                 "Sr": float(res.sum()), "Sxr": np.einsum("nap,n->ap", X, res), "Srr": float((res ** 2).sum())}
            acc = a if acc is None else {k: acc[k] + a[k] for k in acc}
        if acc is None:
            continue
        f = 1.0 / acc["n"]                                        # cada estación pesa 1
        acc = {k: v * f for k, v in acc.items()}
        g = int(dat.grupos[s])
        por_grupo[g] = acc if g not in por_grupo else {k: por_grupo[g][k] + acc[k] for k in acc}
    return por_grupo or None


def _sumar(St, grupos):
    t = None
    for g in grupos:
        t = St[g] if t is None else {k: t[k] + St[g][k] for k in t}
    return t


def ridge_de_sumas(T, alfa, p):
    """Ridge con intercepto sin penalizar a partir de las sumas; alfa = inf deja los coeficientes en cero."""
    n = T["n"]
    xm = T["Sx"][:, p] / n
    rm = T["Sr"] / n
    if not np.isfinite(alfa):
        return rm, np.zeros(len(xm)), xm
    C = T["Sxx"][:, :, p] - n * np.outer(xm, xm)
    c = T["Sxr"][:, p] - n * xm * rm
    b = np.linalg.solve(C + alfa * np.eye(len(xm)), c)
    return rm - float(xm @ b), b, xm


def ecm_de_sumas(T, b0, b, p):
    return (T["Srr"] - 2 * b0 * T["Sr"] - 2 * b @ T["Sxr"][:, p] + b0 ** 2 * T["n"] + 2 * b0 * b @ T["Sx"][:, p]
            + b @ T["Sxx"][:, :, p] @ b)


class AjusteSuelo:
    """Solo las pendientes del uso del suelo, centradas en la media de entrenamiento: el intercepto (una
    recalibración general del inverso de la distancia, que no es efecto del suelo) no se aplica, y sin
    corrección el método es idéntico al inverso de la distancia."""
    def __init__(self, intercepto, coef, alfa, cols, xm):
        self.intercept_, self.coef_, self.alfa, self.cols, self.xm = intercepto, coef, alfa, cols, xm

    def predict(self, X):
        return (X - self.xm) @ self.coef_


def ajuste_desde_sumas(St, vars_suelo, p=0):
    """Elige la penalización con validación interna dejando fuera grupos espaciales (entre ALFAS_RIDGE y no
    corregir) y ajusta con todos los grupos de entrenamiento. p = 0 es el uso del suelo real; p > 0, una
    permutación."""
    ug = sorted(St)
    k = min(5, len(ug))
    if k < 2:
        b0, b, xm = ridge_de_sumas(_sumar(St, ug), np.inf, p)
        return AjusteSuelo(b0, b, np.inf, vars_suelo, xm)
    asign = dict(zip(ug, np.random.default_rng(SEMILLA).permutation(np.arange(len(ug)) % k)))
    candidatos = ALFAS_RIDGE + [np.inf]
    ecm = []
    for a in candidatos:
        e = 0.0
        for f in range(k):
            tr = _sumar(St, [g for g in ug if asign[g] != f])
            te = _sumar(St, [g for g in ug if asign[g] == f])
            b0, b, _ = ridge_de_sumas(tr, a, p)
            e += ecm_de_sumas(te, b0, b, p)
        ecm.append(e)
    alfa = candidatos[int(np.argmin(ecm))]
    b0, b, xm = ridge_de_sumas(_sumar(St, ug), alfa, p)
    return AjusteSuelo(b0, b, alfa, vars_suelo, xm)


def nmae_permutaciones(dat, M, Fte, L, test, train):
    """NMAE de cada estación de prueba con el ajuste real (p = 0) y con cada permutación, frente al inverso
    de la distancia: la diferencia que produce el azar es la distribución de referencia de la prueba."""
    if M["ridge"] is None or not M["ridge_perm"]:
        return []
    ajustes = [M["ridge"]] + M["ridge_perm"]
    Ust = dat.U_apilado(len(ajustes) - 1)
    _, u, P = Ust.shape
    train = np.asarray(train)
    filas = []
    for s in test:
        vec = train[dat.D[s, train] > 0.5]
        y = dat.Y[:, s]
        Yv = dat.Y[:, vec]
        m = np.isfinite(Yv)
        w = m * (1.0 / np.maximum(dat.D[s, vec], 1.0) ** 2)[None, :]
        sw = w.sum(1)
        ok = np.isfinite(y) & (sw > 0)
        if ok.sum() < 30:
            continue
        Wn = w[ok] / sw[ok, None]
        X = Ust[s][None] - (Wn @ Ust[vec].reshape(len(vec), u * P)).reshape(-1, u, P)
        sel = (Fte["sid_idx"].values == s)
        lidw = pd.Series(L["idw"][sel], index=Fte["t"].values[sel]).reindex(np.where(ok)[0]).values
        o = np.exp(y[ok])
        base = 100 * np.nanmean(np.abs(np.exp(lidw) - o)) / np.nanmean(o)
        for k, a in enumerate(ajustes):
            pk = np.exp(lidw + a.predict(X[:, :, k]))
            filas.append({"sid": dat.est["sid"][s], "permutacion": k,
                          "dif_NMAE_pct": 100 * np.nanmean(np.abs(pk - o)) / np.nanmean(o) - base})
    return filas


def log_metodos(M, F, placebo=False):
    """Predicción en logaritmos de cada método de METODOS, con la corrección de Duan incluida."""
    d = F["dmin"].values
    L = {"idw": F["idw2"].values + np.log(factor(M["smear_idw"], d)),
         "idw_suelo": F["idw2_suelo"].values + np.log(factor(M["smear_idw_suelo"], d)),
         "hibrido": log_pred(M["hibrido"], F), "hibrido_suelo": log_pred(M["hibrido_suelo"], F)}
    if M["ridge"] is not None:
        corr = M["ridge"].predict(np.nan_to_num(F[M["cols_du"]].values))
        L["idw_ajuste_suelo"] = L["idw"] + corr
    else:
        L["idw_ajuste_suelo"] = L["idw"]
    L["promedio"] = 0.5 * (L["idw_suelo"] + L["hibrido_suelo"])
    if placebo:
        L["idw_placebo"] = F["idw2_placebo"].values + np.log(factor(M["smear_idw_placebo"], d))
    return L


def log_pred(m, F):
    """Predicción en logaritmos con la corrección de Duan incluida."""
    d = F["dmin"].values if "dmin" in F else None
    return predecir(m, F) + np.log(factor(m.smear_, d, len(F)))


# ═══════════════════════════════════════════════════════════════════
# VALIDACIÓN
# ═══════════════════════════════════════════════════════════════════
def grupo_de(c):
    """Grupo temático de una variable del híbrido, para la importancia por grupos."""
    b = c[6:] if c.startswith("delta_") else c
    if b in ("idw2", "idw1", "vecina", "dmin", "n50", "n150", "idw_sd") or b in COLS_SUELO:
        return "vecinas (interpolación)"
    if b.startswith(("frac_", "poblacion_", "construido_", "luces_", "ndvi")):
        return "uso del suelo"
    if b.startswith(("altitud", "desnivel")):
        return "relieve"
    if any(k in b for k in ("tropomi", "maiac", "merra")):
        return "satélite"
    if b in ("doy_sin", "doy_cos", "dia_semana"):
        return "calendario"
    return "meteorología"


def importancia_grupos(m, F, repeticiones=3, semilla=SEMILLA):
    """Importancia por permutación conjunta de cada grupo de variables: aumento del error cuadrático medio
    (en logaritmos) al permutar juntas todas las variables del grupo. Permutar el grupo entero evita que
    variables correlacionadas (superficie construida, población, luces) se repartan la importancia."""
    muestra = F.sample(min(len(F), 20000), random_state=semilla)
    X = muestra[m.cols_].copy()
    y = muestra["y"].values
    base = float(np.mean((m.predict(X) - y) ** 2))
    rng = np.random.default_rng(semilla)
    out = {}
    grupos = pd.Series({c: grupo_de(c) for c in m.cols_})
    for g, cols in grupos.groupby(grupos).groups.items():
        cols = list(cols)
        aum = []
        for _ in range(repeticiones):
            Xp = X.copy()
            Xp[cols] = X[cols].values[rng.permutation(len(X))]
            aum.append(float(np.mean((m.predict(Xp) - y) ** 2)) - base)
        out[g] = (float(np.mean(aum)), 100 * float(np.mean(aum)) / base, len(cols))
    return out


def validar(dat, diseños, log, coefs=None, imp_grupos=None, perm=None):
    """Predicciones fuera de pliegue para cada diseño y método. Devuelve una tabla día a día. Si se da la
    lista `coefs`, le agrega los coeficientes del ajuste por uso del suelo de cada pliegue."""
    filas = []
    rng = np.random.default_rng(SEMILLA)
    S = len(dat.est)
    for nombre, folds in diseños.items():
        for f in sorted(set(folds)):
            test = np.where(folds == f)[0]
            train = np.where(folds != f)[0]
            if len(train) < 3 or len(test) == 0:
                continue
            t0 = time.time()
            Ftr = dat.filas_entrenamiento(train, rng, True)
            n_perm = N_PERMUTACIONES if (perm is not None and nombre.startswith("kNNDM")) else 0
            M = ajustar_metodos(Ftr, dat, train, n_perm)
            Fte = dat.filas_prueba(test, train, True)
            L = log_metodos(M, Fte, placebo=True)
            if n_perm:
                perm += [{"diseño": nombre, **x} for x in nmae_permutaciones(dat, M, Fte, L, test, train)]
            if coefs is not None and M["ridge"] is not None:
                coefs.append({"diseño": nombre, "pliegue": f, "alfa": float(M["ridge"].alfa),
                              "intercepto": float(M["ridge"].intercept_),
                              **dict(zip(M["cols_du"], M["ridge"].coef_.astype(float)))})
            if imp_grupos is not None and nombre == "kNNDM":
                for g, (a, pct, n) in importancia_grupos(M["hibrido_suelo"], Fte).items():
                    imp_grupos.append({"pliegue": f, "grupo": g, "variables": n, "aumento_ecm_log": a,
                                       "aumento_ecm_pct": pct})
            Ftr0 = dat.filas_entrenamiento(train, rng, False)
            m0 = ajustar(Ftr0)
            Fte0 = dat.filas_prueba(test, train, False)
            p0 = pd.Series(predecir(m0, Fte0), index=pd.MultiIndex.from_arrays([Fte0["sid_idx"], Fte0["t"]]))
            base = pd.DataFrame({"diseño": nombre, "pliegue": f, "sid_idx": Fte["sid_idx"].values,
                                 "t": Fte["t"].values, "obs": np.exp(Fte["y"].values),
                                 "dmin_km": Fte["dmin"].values,
                                 **{mt: np.exp(L[mt]) for mt in METODOS + ["idw_placebo"]},
                                 "vecina": np.exp(Fte["vecina"].values),
                                 "covariables": np.exp(p0.reindex(pd.MultiIndex.from_arrays(
                                     [Fte["sid_idx"], Fte["t"]])).values) * m0.smear_["_todas"],
                                 **{f"log_res_{mt}": Fte["y"].values - L[mt] for mt in METODOS + ["idw_placebo"]}})
            filas.append(base)
            log(f"    {nombre} pliegue {f}: {len(train)} estaciones de entrenamiento, {len(test)} de prueba, "
                f"{len(Ftr)} filas, {time.time() - t0:.0f} s")
    return pd.concat(filas, ignore_index=True)


def r2(o, p):
    ok = np.isfinite(o) & np.isfinite(p)
    o, p = o[ok], p[ok]
    if len(o) < 30:
        return np.nan
    return 1 - ((p - o) ** 2).sum() / ((o - o.mean()) ** 2).sum()


def metricas_estacion(cv, dat, metodos):
    """Métricas por diseño, método y estación de prueba."""
    filas = []
    fechas = pd.DatetimeIndex(dat.fechas)
    for (dis, s), g in cv.groupby(["diseño", "sid_idx"]):
        o = g["obs"].values
        mes = fechas[g["t"].values].month
        clim = pd.Series(o).groupby(mes).transform("mean").values
        for mt in metodos:
            p = g[mt].values
            ok = np.isfinite(p) & np.isfinite(o)
            if ok.sum() < 30:
                continue
            an_o = o - clim
            an_p = p - pd.Series(p).groupby(mes).transform("mean").values
            filas.append({"diseño": dis, "sid": dat.est["sid"][s], "departamento": dat.est["departamento"][s],
                          "metodo": mt, "n_dias": int(ok.sum()), "dmin_mediana_km": float(np.nanmedian(g["dmin_km"])),
                          "R2": r2(o, p), "r": float(np.corrcoef(o[ok], p[ok])[0, 1]),
                          "r_anomalias": float(np.corrcoef(an_o[ok], an_p[ok])[0, 1]),
                          "error_medio_pct": float(100 * (p[ok].mean() - o[ok].mean()) / o[ok].mean()),
                          "NMAE_pct": float(100 * np.abs(p[ok] - o[ok]).mean() / o[ok].mean())})
    return pd.DataFrame(filas)


def clase_km(d):
    return pd.cut(d, CLASES_KM, labels=ETIQ_CLASES, right=False)


def errores_agregados(cv, dat, p, diseño="kNNDM"):
    """Error de la media anual y de los días sobre el límite, por estación-año de prueba y método."""
    fechas = pd.DatetimeIndex(dat.fechas)
    x = cv[cv["diseño"] == diseño].copy()
    x["anio"] = fechas[x["t"].values].year
    lim = LIMITE_2254[p] or GUIA_OMS[p]
    filas = []
    for (s, a), g in x.groupby(["sid_idx", "anio"]):
        if len(g) < 180:                                  # al menos 180 días medidos en el año
            continue
        for mt in METODOS:
            gg = g[np.isfinite(g[mt])]
            if len(gg) < 180:
                continue
            filas.append({"metodo": mt, "sid": dat.est["sid"][s], "anio": a, "n_dias": len(gg),
                          "dmin_mediana_km": float(np.nanmedian(gg["dmin_km"])),
                          "media_obs": gg["obs"].mean(), "media_pred": gg[mt].mean(),
                          "error_rel_media": gg[mt].mean() / gg["obs"].mean() - 1,
                          "dias_sobre_obs": int((gg["obs"] > lim).sum()), "dias_sobre_pred": int((gg[mt] > lim).sum()),
                          "frac_sobre_obs": float((gg["obs"] > lim).mean()),
                          "frac_sobre_pred": float((gg[mt] > lim).mean())})
    t = pd.DataFrame(filas)
    if len(t):
        t["clase_km"] = clase_km(t["dmin_mediana_km"])
    return t


MIN_ESTACIONES_CLASE = 8      # estaciones mínimas para los intervalos diarios de una clase de distancia
MIN_ANIOS_CLASE = 20          # estaciones-año mínimas para los intervalos de la media anual


def cuantiles_agrupados(x, col, niveles, unidad, minimo):
    """Cuantiles de col por clase de distancia. Una clase con menos de `minimo` unidades distintas (estaciones
    o estaciones-año) toma también las filas de las clases vecinas, ampliando hacia ambos lados hasta
    alcanzarlo: así una clase con dos o tres estaciones no define sola el intervalo."""
    filas = {}
    clases = list(ETIQ_CLASES)
    for i, c in enumerate(clases):
        for r in range(len(clases)):
            sel = clases[max(0, i - r):i + r + 1]
            sub = x[x["clase_km"].astype(str).isin(sel)]
            if sub[unidad].nunique() >= minimo or r == len(clases) - 1:
                break
        q = sub[col].quantile(niveles) if len(sub) else pd.Series(np.nan, index=niveles)
        filas[c] = {**{nv: float(q.loc[nv]) for nv in niveles}, "unidades": int(sub[unidad].nunique()),
                    "clases_usadas": "+".join(sel)}
    return pd.DataFrame(filas).T


def cuantiles_conformes(cv, metodo, diseño="kNNDM"):
    """Intervalos del 90 % por clase de distancia a partir de los residuos logarítmicos de la validación
    kNNDM. El nivel de los cuantiles se calibra para que la cobertura en validación cruzada (cuantiles de
    los otros pliegues aplicados a cada pliegue) llegue al 90 %: si los cuantiles 5 y 95 % cubren menos,
    se ensanchan hasta 1 y 99 %, y la cobertura lograda queda anotada."""
    col = f"log_res_{metodo}"
    x = cv[(cv["diseño"] == diseño) & np.isfinite(cv[col])].copy()
    x["clase_km"] = clase_km(x["dmin_km"])

    def cobertura(a):
        cob = []
        for f in sorted(x["pliegue"].unique()):
            o, b = x[x["pliegue"] != f], x[x["pliegue"] == f]
            qq = cuantiles_agrupados(o, col, [a, 1 - a], "sid_idx", MIN_ESTACIONES_CLASE)
            lo = qq.reindex(b["clase_km"].astype(str))[a].values.astype(float)
            hi = qq.reindex(b["clase_km"].astype(str))[1 - a].values.astype(float)
            cob.append(((b[col].values >= lo) & (b[col].values <= hi)).mean())
        return float(np.mean(cob)) if cob else np.nan

    for a in (0.05, 0.04, 0.03, 0.02, 0.01, 0.005):
        c = cobertura(a)
        if c >= 0.90:
            break
    qa = cuantiles_agrupados(x, col, [a, 1 - a], "sid_idx", MIN_ESTACIONES_CLASE)
    q = pd.DataFrame({"q_inf": qa[a].astype(float), "q_sup": qa[1 - a].astype(float)}, index=qa.index)
    q.index = pd.CategoricalIndex(q.index, categories=ETIQ_CLASES, ordered=True, name="clase_km")
    q["n"] = x.groupby("clase_km", observed=False).size().reindex(q.index).values
    q["estaciones_usadas"] = qa["unidades"].values
    q["clases_usadas"] = qa["clases_usadas"].values
    q["cuantil_inferior_usado"] = a
    q["cobertura_cv"] = c
    q["metodo"] = metodo
    q["diseño"] = diseño
    return q


def grupos_espaciales(est, km_corte=GRUPO_KM):
    """Grupos de estaciones cercanas (enlace simple a km_corte): los errores de estaciones vecinas no son
    independientes, así que el remuestreo toma grupos, no estaciones."""
    if len(est) < 2:
        return np.zeros(len(est), dtype=int)
    D = matriz_km(est, est)
    from scipy.spatial.distance import squareform
    np.fill_diagonal(D, 0)
    Z = linkage(squareform(D, checks=False), method="single")
    return fcluster(Z, t=km_corte, criterion="distance")


def seleccion_metodo(me, dat, diseño, metrica="NMAE_pct", perm=None):
    """Regla de elección declarada antes de ver los resultados.
      1. Se recorren los métodos en orden de complejidad (METODOS). Uno más complejo reemplaza al elegido
         solo si reduce el NMAE medio por estación en al menos MEJORA_MINIMA puntos aun quitando cualquier
         grupo espacial de estaciones (la mejora no puede depender de un solo grupo) y el intervalo del
         95 % de la diferencia (remuestreo por grupos espaciales) queda por debajo de cero.
      2. Los métodos con similitud de uso del suelo (CON_PLACEBO) solo son elegibles si la
         interpolación por similitud de suelo supera a su placebo (el uso del suelo permutado entre estaciones) con un
         intervalo que excluya el cero; si no, la ganancia no se puede atribuir al uso del suelo.
      3. El ajuste por uso del suelo solo es elegible si su mejora sobre el inverso de la distancia es mayor
         que la de todas las N_PERMUTACIONES repeticiones con el uso del suelo permutado entre estaciones
         (prueba de permutación, p <= 0.05), cada una con su propio ajuste y su propia validación.
    Así, probar varias combinaciones no premia por azar a la más compleja. Con menos de 10 grupos
    espaciales el intervalo es poco fiable y queda anotado."""
    x = me[me["diseño"] == diseño].pivot_table(index="sid", columns="metodo", values=metrica)
    x = x[[mt for mt in METODOS + ["idw_placebo"] if mt in x.columns]].dropna()
    grupos = pd.Series(grupos_espaciales(dat.est), index=dat.est["sid"]).reindex(x.index).values
    ug = np.unique(grupos)
    rng = np.random.default_rng(SEMILLA)
    muestras = [rng.choice(ug, len(ug)) for _ in range(N_REMUESTREOS)]
    idx = {g: np.where(grupos == g)[0] for g in ug}

    def diferencia(a, b):
        dlt = (x[a] - x[b]).values                    # negativo: a tiene menor error que b
        boot = np.array([dlt[np.concatenate([idx[g] for g in mm])].mean() for mm in muestras])
        jk = max(float(dlt[grupos != g].mean()) for g in ug) if len(ug) > 1 else float(dlt.mean())
        return float(dlt.mean()), float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5)), jk

    filas = []

    def fila(a, b, papel):
        dm, lo, hi, jk = diferencia(a, b)
        filas.append({"diseño": diseño, "metodo": a, "frente_a": b, "papel": papel, "metrica": metrica,
                      "diferencia_media": dm, "ic95_inf": lo, "ic95_sup": hi,
                      "diferencia_peor_sin_un_grupo": jk, "estaciones": len(x),
                      "grupos_espaciales": len(ug), "intervalo_poco_fiable": len(ug) < 10})
        return dm, hi, jk

    suelo_valido = False
    if {"idw_suelo", "idw_placebo"} <= set(x.columns):
        dm, hi, jk = fila("idw_suelo", "idw_placebo", "control placebo del uso del suelo")
        suelo_valido = hi < 0 and jk < 0
    ajuste_valido, p_perm = False, np.nan
    if perm is not None and len(perm) and "idw_ajuste_suelo" in x.columns:
        q = perm[(perm["diseño"] == diseño) & perm["sid"].isin(x.index)]
        Dp = q.groupby("permutacion")["dif_NMAE_pct"].mean()
        if 0 in Dp.index and len(Dp) > 1:
            d0 = Dp.loc[0]
            nulos = Dp.drop(0)
            p_perm = (1 + int((nulos <= d0).sum())) / (1 + len(nulos))
            ajuste_valido = (p_perm <= 0.05) and d0 < 0
            filas.append({"diseño": diseño, "metodo": "idw_ajuste_suelo", "frente_a": "idw",
                          "papel": "prueba de permutación del ajuste por suelo", "metrica": metrica,
                          "diferencia_media": float(d0), "ic95_inf": float(nulos.quantile(0.025)),
                          "ic95_sup": float(nulos.quantile(0.975)), "diferencia_peor_sin_un_grupo": np.nan,
                          "estaciones": int(q["sid"].nunique()), "grupos_espaciales": len(ug),
                          "intervalo_poco_fiable": False, "p_permutacion": p_perm,
                          "permutaciones": len(nulos)})
    elegido = METODOS[0]
    for mt in METODOS[1:]:
        if mt not in x.columns:
            continue
        if elegido != "idw":
            fila(mt, "idw", "referencia")
        dm, hi, jk = fila(mt, elegido, "frente al elegido hasta ahora")
        if (hi < 0 and jk <= -MEJORA_MINIMA and (suelo_valido or mt not in CON_PLACEBO)
                and (ajuste_valido or mt != "idw_ajuste_suelo")):
            elegido = mt
    t = pd.DataFrame(filas)
    t["suelo_supera_placebo"] = suelo_valido
    t["ajuste_supera_permutaciones"] = ajuste_valido
    t["elegido_en_el_diseño"] = elegido
    return elegido, t


def error_segun_suelo(me, dat, diseño="kNNDM"):
    """Relación entre el error fuera de pliegue de cada estación y su uso del suelo.
    1. Correlación de rangos (Spearman) entre el error medio (%) o el NMAE de cada estación y cada variable
       de uso del suelo, con intervalo del 95 % por remuestreo de grupos espaciales de estaciones.
    2. Error por clase de urbanización (terciles de la fracción construida en 1 km de las estaciones), junto
       con la fracción de la población de los 12 municipios y el número de cabeceras en cada clase, para ver
       si los municipios caen donde el modelo se equivoca más."""
    from scipy.stats import spearmanr
    x = me[me["diseño"] == diseño]
    S = len(dat.est)
    raw = pd.DataFrame({c: dat.F[c].values for c in dat.vars_suelo})
    sids = dat.est["sid"].astype(str).tolist()
    raw_e = raw.iloc[:S].copy()
    raw_e.index = sids
    grupos = pd.Series(grupos_espaciales(dat.est), index=sids)
    rng = np.random.default_rng(SEMILLA)
    corr = []
    for mt, g in x.groupby("metodo"):
        g = g.set_index("sid")
        ug = grupos.reindex(g.index).values
        u = np.unique(ug)
        idx = {k: np.where(ug == k)[0] for k in u}
        muestras = [np.concatenate([idx[k] for k in rng.choice(u, len(u))]) for _ in range(500)]
        for metrica in ("error_medio_pct", "NMAE_pct"):
            e = g[metrica].values
            for c in dat.vars_suelo:
                v = raw_e.reindex(g.index)[c].values
                ok = np.isfinite(e) & np.isfinite(v)
                if ok.sum() < 8 or np.nanstd(v[ok]) == 0:
                    continue
                rho = spearmanr(e[ok], v[ok]).statistic
                boot = []
                for mm in muestras:
                    mm = mm[ok[mm]]
                    if len(mm) >= 8 and np.std(v[mm]) > 0:
                        boot.append(spearmanr(e[mm], v[mm]).statistic)
                lo, hi = (np.nanpercentile(boot, [2.5, 97.5]) if len(boot) > 50 else (np.nan, np.nan))
                corr.append({"diseño": diseño, "metodo": mt, "error": metrica, "variable_suelo": c,
                             "rho_spearman": float(rho), "ic95_inf": float(lo), "ic95_sup": float(hi),
                             "estaciones": int(ok.sum()), "grupos_espaciales": len(u)})
    clases = []
    if "frac_construido_1km" in raw.columns:
        fe = raw_e["frac_construido_1km"].values
        cortes = np.nanpercentile(fe, [100 / 3, 200 / 3])
        etiq = np.array(["baja", "media", "alta"])
        clase = lambda v: etiq[np.digitize(v, cortes)]
        ce = pd.Series(clase(fe), index=raw_e.index)
        mun = dat.mun
        fm = raw.iloc[S:]["frac_construido_1km"].values
        cm = clase(np.nan_to_num(fm))
        cel = (mun["tipo"] == "celda").values
        pob = mun["poblacion"].fillna(0).values
        for mt, g in x.groupby("metodo"):
            g = g.assign(clase=ce.reindex(g["sid"]).values)
            for k, gg in g.groupby("clase"):
                clases.append({"diseño": diseño, "metodo": mt, "urbanizacion": k,
                               "frac_construido_1km_desde": float([0, *cortes][list(etiq).index(k)]),
                               "frac_construido_1km_hasta": float([*cortes, 1][list(etiq).index(k)]),
                               "estaciones": len(gg), "error_medio_pct_mediana": float(gg["error_medio_pct"].median()),
                               "NMAE_pct_mediana": float(gg["NMAE_pct"].median()),
                               "R2_mediana": float(gg["R2"].median()),
                               "fraccion_poblacion_municipios": float(pob[cel & (cm == k)].sum() / max(pob[cel].sum(), 1)),
                               "cabeceras": int(((~cel) & (cm == k)).sum())})
    return pd.DataFrame(corr), pd.DataFrame(clases)


# ═══════════════════════════════════════════════════════════════════
# ÁREA DE APLICABILIDAD
# ═══════════════════════════════════════════════════════════════════
def area_aplicabilidad(dat, folds, importancia):
    """Índice de disimilitud (Meyer y Pebesma, 2021) con covariables de lugar: fijas y medias de las
    dinámicas, estandarizadas con las estaciones y ponderadas por su importancia en el modelo."""
    S = len(dat.est)
    cols = [c for c in dat.fix_cols] + [c for c in dat.dyn_cols]
    A = []
    for c in cols:
        if c in dat.C:
            A.append(np.nanmean(dat.C[c], axis=0))
        else:
            A.append(dat.F[c].values)
    A = np.array(A, dtype=float).T                                     # (S+M) x V
    mu = np.nanmean(A[:S], 0)
    sd = np.nanstd(A[:S], 0)
    sd[sd == 0] = 1
    Z = (A - mu) / sd
    Z = np.nan_to_num(Z)
    w = np.array([max(importancia.get(c, 0.0), 0.0) for c in cols])
    if w.sum() == 0:
        w = np.ones(len(cols))
    Z = Z * w
    Ze, Zm = Z[:S], Z[S:]
    De = np.sqrt(((Ze[:, None, :] - Ze[None, :, :]) ** 2).sum(-1))
    dbar = De[np.triu_indices(S, 1)].mean()
    di_cv = np.array([De[i, folds != folds[i]].min() for i in range(S)]) / dbar
    q1, q3 = np.percentile(di_cv, [25, 75])
    umbral = min(q3 + 1.5 * (q3 - q1), di_cv.max())
    Dm = np.sqrt(((Zm[:, None, :] - Ze[None, :, :]) ** 2).sum(-1))
    di_m = Dm.min(1) / dbar
    return pd.DataFrame({"municipio": dat.mun["municipio"].values, "pid": dat.mun["pid"].values,
                         "tipo": dat.mun["tipo"].values, "DI": di_m, "umbral_DI": umbral,
                         "dentro_area_aplicabilidad": di_m <= umbral})


# ═══════════════════════════════════════════════════════════════════
# FLUJO POR CONTAMINANTE
# ═══════════════════════════════════════════════════════════════════
def correr_contaminante(p, obs, est, mun, dinam, fijas, fechas, salida, log, prueba=False):
    os.makedirs(salida, exist_ok=True)
    dat = Datos(obs, est, mun, dinam, fijas, p, fechas)
    S = len(dat.est)
    log(f"\n=== {NOMBRE[p]}: {S} estaciones con al menos {MIN_DIAS} días válidos ===")
    if S < 8:
        log("  muy pocas estaciones; se omite")
        return None
    dat.est.assign(dist_municipio_mas_cercano_km=dat.DM.min(0)).to_csv(os.path.join(salida, f"{p}_estaciones.csv"),
                                                                      index=False)
    k = min(K_PLIEGUES, max(3, S // 3)) if not prueba else 3
    habitados = dat.mun[(dat.mun["tipo"] == "cabecera") | (dat.mun["poblacion"].fillna(0) > 0)]
    f_knndm, info = knndm(dat.est, habitados, k=k)
    log(f"  kNNDM con las celdas habitadas y las cabeceras: {info}")
    f_cab, info_cab = knndm(dat.est, dat.mun[dat.mun["tipo"] == "cabecera"], k=k)
    log(f"  kNNDM con las cabeceras solas: {info_cab}")
    dep = dat.est["departamento"].values
    f_dep = pd.factorize(dep)[0]
    f_azar = np.random.default_rng(SEMILLA).permutation(np.arange(S) % k)
    diseños = {"kNNDM": f_knndm, "kNNDM_cabeceras": f_cab}
    if not prueba:
        diseños.update({"departamento_fuera": f_dep, "azar": f_azar})
    coefs, imp_g, perm = [], [], []
    cv = validar(dat, diseños, log, coefs, imp_g, perm)
    perm = pd.DataFrame(perm)
    if len(perm):
        perm.to_csv(os.path.join(salida, f"{p}_permutaciones_ajuste_suelo.csv.gz"), index=False)
    cv.to_csv(os.path.join(salida, f"{p}_validacion_diaria.csv.gz"), index=False)
    metodos = METODOS + ["idw_placebo", "vecina", "covariables"]
    me = metricas_estacion(cv, dat, metodos)
    me.to_csv(os.path.join(salida, f"{p}_validacion_por_estacion.csv"), index=False)
    me["clase_km"] = clase_km(me["dmin_mediana_km"])
    resumen = (me.groupby(["diseño", "metodo"])[["R2", "r", "r_anomalias", "error_medio_pct", "NMAE_pct"]]
               .median().round(3))
    resumen["estaciones"] = me.groupby(["diseño", "metodo"]).size()
    resumen.to_csv(os.path.join(salida, f"{p}_validacion_resumen.csv"))
    lejos = me["diseño"].isin(["departamento_fuera", "azar"]) if not prueba else me["diseño"].notna()
    por_dist = (me[lejos].groupby(["metodo", "clase_km"], observed=False)
                [["R2", "r", "NMAE_pct", "error_medio_pct"]].median().round(3))
    por_dist["estaciones"] = me[lejos].groupby(["metodo", "clase_km"], observed=False).size()
    por_dist.to_csv(os.path.join(salida, f"{p}_error_por_distancia.csv"))
    for ds in ("kNNDM", "kNNDM_cabeceras"):
        log(f"  validación {ds} (medianas por estación):")
        log(resumen.loc[ds].to_string())
    # elección del método con la regla declarada (el más simple salvo mejora con intervalo que excluye cero)
    eleccion, tablas_sel = {}, []
    for ds in ("kNNDM", "kNNDM_cabeceras"):
        el, t = seleccion_metodo(me, dat, ds, perm=perm)
        eleccion[ds] = el
        tablas_sel.append(t)
        pl = t[t["papel"].str.startswith("control")]
        if len(pl):
            r = pl.iloc[0]
            log(f"  {ds}: suelo frente a placebo, {r['diferencia_media']:+.2f} puntos de NMAE "
                f"(IC 95 % {r['ic95_inf']:+.2f} a {r['ic95_sup']:+.2f}; {int(r['grupos_espaciales'])} grupos)"
                + ("" if r["ic95_sup"] < 0 else " → los métodos con suelo no son elegibles"))
        pp = t[t["papel"].str.startswith("prueba de permutación")]
        if len(pp):
            r = pp.iloc[0]
            log(f"  {ds}: ajuste por suelo frente a idw, {r['diferencia_media']:+.2f} puntos de NMAE; con el suelo "
                f"permutado, de {r['ic95_inf']:+.2f} a {r['ic95_sup']:+.2f} (p = {r['p_permutacion']:.2f}, "
                f"{int(r['permutaciones'])} permutaciones)"
                + ("" if r["p_permutacion"] <= 0.05 and r["diferencia_media"] < 0 else " → el ajuste no es elegible"))
        log(f"  método elegido con {ds}: {el} ({DESCRIPCION[el]})")
    pd.concat(tablas_sel, ignore_index=True).to_csv(os.path.join(salida, f"{p}_eleccion_metodo.csv"), index=False)
    # ¿el error depende del uso del suelo? (diagnóstico, no cambia las predicciones)
    ec, ecl = error_segun_suelo(me, dat, "kNNDM")
    ec.to_csv(os.path.join(salida, f"{p}_error_segun_suelo.csv"), index=False)
    ecl.to_csv(os.path.join(salida, f"{p}_error_por_urbanizacion.csv"), index=False)
    if len(ec):
        sig = ec[(ec["metodo"].isin(["idw", "hibrido"])) & (ec["error"] == "error_medio_pct") &
                 ((ec["ic95_inf"] > 0) | (ec["ic95_sup"] < 0))]
        log(f"  error medio frente al uso del suelo (kNNDM): {len(sig)} relaciones con intervalo que excluye cero "
            f"en idw o hibrido" + ("".join(f"\n    {r.metodo} ~ {r.variable_suelo}: rho {r.rho_spearman:+.2f} "
                                          f"({r.ic95_inf:+.2f} a {r.ic95_sup:+.2f})" for r in sig.itertuples())))
    if len(ecl):
        for r in ecl[ecl["metodo"].isin(["idw", eleccion["kNNDM"]])].itertuples():
            log(f"    {r.metodo}, urbanización {r.urbanizacion}: {r.estaciones} estaciones, error medio "
                f"{r.error_medio_pct_mediana:+.1f} %, NMAE {r.NMAE_pct_mediana:.1f} %; "
                f"{100 * r.fraccion_poblacion_municipios:.0f} % de la población de los municipios, {r.cabeceras} cabeceras")
    if imp_g:
        ig = pd.DataFrame(imp_g).groupby("grupo").agg(variables=("variables", "first"),
                                                      aumento_ecm_pct_media=("aumento_ecm_pct", "mean"),
                                                      aumento_ecm_pct_min=("aumento_ecm_pct", "min"),
                                                      aumento_ecm_pct_max=("aumento_ecm_pct", "max"),
                                                      pliegues=("pliegue", "nunique"))
        ig = ig.sort_values("aumento_ecm_pct_media", ascending=False)
        ig.to_csv(os.path.join(salida, f"{p}_importancia_grupos.csv"))
        log("  importancia por grupos (híbrido con suelo, pliegues kNNDM; % de aumento del error al permutar):")
        log(ig.round(1).to_string())
    # el error de cada enfoque se mide con el diseño que reproduce sus distancias: kNNDM (celdas habitadas)
    # para la media poblacional y kNNDM_cabeceras para la cabecera
    aggs = {ds: errores_agregados(cv, dat, p, ds) for ds in ("kNNDM", "kNNDM_cabeceras")}
    agg = pd.concat([a.assign(diseño=ds) for ds, a in aggs.items()], ignore_index=True)
    agg.to_csv(os.path.join(salida, f"{p}_error_media_anual_y_excedencias.csv"), index=False)
    qs = {(ds, mt): cuantiles_conformes(cv, mt, ds) for ds in ("kNNDM", "kNNDM_cabeceras") for mt in METODOS}
    pd.concat(qs.values()).to_csv(os.path.join(salida, f"{p}_intervalos_conformes.csv"))
    for (ds, mt), q in qs.items():
        log(f"  intervalos de {mt} ({ds}): cobertura en validación cruzada {q['cobertura_cv'].iloc[0]:.2f} con "
            f"cuantiles {q['cuantil_inferior_usado'].iloc[0]:.3f}-{1 - q['cuantil_inferior_usado'].iloc[0]:.3f}")

    # ── modelo final con todas las estaciones ──
    rng = np.random.default_rng(SEMILLA + 1)
    Fall = dat.filas_entrenamiento(np.arange(S), rng, True)
    M = ajustar_metodos(Fall, dat, np.arange(S), 0)
    # importancia por permutación con las filas de prueba del primer pliegue kNNDM (modelo híbrido con suelo de
    # ese pliegue, que contiene todas las variables)
    test = np.where(f_knndm == 0)[0]
    train = np.where(f_knndm != 0)[0]
    mi = ajustar(dat.filas_entrenamiento(train, rng, True), excluir=COLS_PLACEBO)
    Fte = dat.filas_prueba(test, train, True)
    muestra = Fte.sample(min(len(Fte), 20000), random_state=SEMILLA)
    pi = permutation_importance(mi, muestra[mi.cols_], muestra["y"], n_repeats=3, random_state=SEMILLA,
                                n_jobs=1)
    imp = pd.Series(pi.importances_mean, index=mi.cols_).sort_values(ascending=False)
    imp.to_csv(os.path.join(salida, f"{p}_importancia.csv"), header=["importancia_permutacion"])
    # importancia de cada covariable de lugar: la suya más la de su diferencia con las vecinas
    imp_lugar = {c: imp.get(c, 0) + imp.get(f"delta_{c}", 0) for c in dat.fix_cols + dat.dyn_cols}
    # coeficientes de ponderación del uso del suelo: modelo final, intervalo por remuestreo de grupos
    # espaciales (con la penalización elegida) y variación entre pliegues kNNDM
    if M["ridge"] is not None:
        cf = pd.DataFrame(coefs)
        cfk = cf[cf["diseño"] == "kNNDM"]
        St = M["sumas_ajuste"]
        ug = sorted(St)
        rngb = np.random.default_rng(SEMILLA)
        boot = []
        for _ in range(500):
            boot.append(ridge_de_sumas(_sumar(St, rngb.choice(ug, len(ug))), M["ridge"].alfa, 0)[1])
        boot = np.array(boot)
        filas_c = []
        for k, c in enumerate(M["cols_du"]):
            v = c[3:]
            if len(cfk) and c not in cfk:
                continue
            b = float(M["ridge"].coef_[k])
            lo, hi = np.percentile(boot[:, k], [2.5, 97.5])
            filas_c.append({"variable": v, "en_logaritmo": v in LOG_SUELO,
                            "desviacion_estandar_estaciones": float(dat.sd_suelo[dat.vars_suelo.index(v)]),
                            "alfa_elegido": M["ridge"].alfa,
                            "coeficiente_log": b, "cambio_pct_por_1_de": 100 * (np.exp(b) - 1),
                            "ic95_inf_pct": 100 * (np.exp(lo) - 1), "ic95_sup_pct": 100 * (np.exp(hi) - 1),
                            "intervalo_excluye_cero": bool(lo > 0 or hi < 0),
                            "cambio_pct_min_pliegues": 100 * (np.exp(cfk[c].min()) - 1) if len(cfk) else np.nan,
                            "cambio_pct_max_pliegues": 100 * (np.exp(cfk[c].max()) - 1) if len(cfk) else np.nan,
                            "grupos_espaciales": len(ug)})
        cft = pd.DataFrame(filas_c)
        cft.to_csv(os.path.join(salida, f"{p}_coeficientes_suelo.csv"), index=False)
        cf.to_csv(os.path.join(salida, f"{p}_coeficientes_suelo_por_pliegue.csv"), index=False)
        log("  coeficientes del ajuste por uso del suelo (% de cambio por una desviación estándar más que las vecinas):")
        log(f"    penalización elegida {M['ridge'].alfa} (inf = sin corrección); en los pliegues kNNDM: "
            f"{sorted(cfk['alfa'].tolist()) if len(cfk) else '-'}")
        log(cft[["variable", "cambio_pct_por_1_de", "ic95_inf_pct", "ic95_sup_pct",
                 "intervalo_excluye_cero"]].round(2).to_string(index=False))
    aoa = area_aplicabilidad(dat, f_knndm, imp_lugar)
    aoa["contaminante"] = p
    # ── predicción en los municipios: cabecera y todas las celdas de la rejilla ──
    aoa.to_csv(os.path.join(salida, f"{p}_area_aplicabilidad.csv"), index=False)
    di = aoa.set_index("pid")
    T = len(dat.fechas)
    anio = pd.DatetimeIndex(dat.fechas).year.values
    lim, lim_a, oms_a = LIMITE_2254[p] or GUIA_OMS[p], ANUAL_2254[p], ANUAL_OMS[p]
    err_anual = {}
    for ds, a in aggs.items():
        for mt in METODOS:
            if len(a) and (a["metodo"] == mt).any():
                b = a[a["metodo"] == mt].assign(estacion_anio=lambda t: t["sid"].astype(str) + "_" + t["anio"].astype(str))
                ea = cuantiles_agrupados(b, "error_rel_media", [0.05, 0.95], "estacion_anio", MIN_ANIOS_CLASE)
                ea.index = pd.CategoricalIndex(ea.index, categories=ETIQ_CLASES, ordered=True)
                err_anual[(ds, mt)] = ea[[0.05, 0.95]].astype(float)

    def intervalo(mt, lv, dmin, ds):
        q = qs[(ds, mt)].reindex(clase_km(dmin))
        return np.exp(lv + q["q_inf"].values), np.exp(lv + q["q_sup"].values)

    def intervalo_anual(mt, media, dmin_med, ds):
        if (ds, mt) not in err_anual:
            return np.nan, np.nan
        e = err_anual[(ds, mt)].reindex(clase_km(np.array([dmin_med])))
        return media / (1 + e[0.95].values[0]), media / (1 + e[0.05].values[0])

    diario, anual, celdas = [], [], []
    for mu, g in dat.mun.groupby("municipio", sort=False):
        idx = g.index.values
        V = {mt: np.full((len(idx), T), np.nan) for mt in METODOS}
        Dm = np.full((len(idx), T), np.nan)
        # filas de todos los puntos del municipio en paralelo y una sola predicción por método (el modelo de
        # árboles predice en paralelo un lote grande mucho más rápido que punto por punto)
        Fm = pd.concat(mapa(dat.filas_municipio, list(idx)), ignore_index=True)
        Dm[:] = Fm["dmin"].values.reshape(len(idx), T)
        for mt, lv in log_metodos(M, Fm).items():
            V[mt][:] = np.asarray(lv).reshape(len(idx), T)
        es_cab = (g["tipo"] == "cabecera").values
        es_cel = ~es_cab
        w_pob = g["poblacion"].fillna(0).values[es_cel]
        w_are = g["area_km2"].fillna(0).values[es_cel]
        if w_pob.sum() <= 0:
            w_pob = w_are
        for mt in METODOS:
            lc = V[mt][es_cab][0]
            dc = Dm[es_cab][0]
            c_inf, c_sup = intervalo(mt, lc, dc, "kNNDM_cabeceras")
            X = np.exp(V[mt][es_cel])                                     # celdas x días
            ok = np.isfinite(X)

            def ponderada(w):
                ww = ok * w[:, None]
                s = ww.sum(0)
                return np.where(s > 0, (np.where(ok, X, 0) * ww).sum(0) / np.where(s > 0, s, 1), np.nan)
            pob = ponderada(w_pob)
            ter = ponderada(w_are)
            # distancia típica de la población a su estación más cercana, para elegir el intervalo
            dpob = np.array([np.average(Dm[es_cel][:, j][np.isfinite(Dm[es_cel][:, j])],
                                        weights=w_pob[np.isfinite(Dm[es_cel][:, j])] + 1e-9)
                             if np.isfinite(Dm[es_cel][:, j]).any() else np.nan for j in range(T)])
            p_inf, p_sup = intervalo(mt, np.log(pob), dpob, "kNNDM")
            diario.append(pd.DataFrame({"municipio": mu, "metodo": mt, "fecha": dat.fechas, "contaminante": p,
                                        "cabecera": np.exp(lc), "cabecera_inferior_90": c_inf,
                                        "cabecera_superior_90": c_sup, "media_poblacional": pob,
                                        "poblacional_inferior_90": p_inf, "poblacional_superior_90": p_sup,
                                        "media_territorial": ter, "vecina_cabecera_km": dc,
                                        "vecina_poblacion_km": dpob}))
            # celdas: media anual por celda (para mapas y fracción de población sobre los valores de referencia)
            cel = g[es_cel]
            for y in sorted(set(anio)):
                k = anio == y
                mc = np.nanmean(X[:, k], axis=1)
                celdas.append(pd.DataFrame({"municipio": mu, "metodo": mt, "anio": y, "pid": cel["pid"].values,
                                            "lat": cel["lat"].values, "lon": cel["lon"].values,
                                            "poblacion": cel["poblacion"].values, "area_km2": cel["area_km2"].values,
                                            "media_anual": mc, "vecina_mediana_km": np.nanmedian(Dm[es_cel][:, k], 1),
                                            "DI": di.loc[cel["pid"], "DI"].values,
                                            "dentro_area_aplicabilidad": di.loc[cel["pid"], "dentro_area_aplicabilidad"].values}))
                cab_m = float(np.nanmean(np.exp(lc[k])))
                pob_m = float(np.nanmean(pob[k]))
                ci, cs = intervalo_anual(mt, cab_m, float(np.nanmedian(dc[k])), "kNNDM_cabeceras")
                pi_, ps_ = intervalo_anual(mt, pob_m, float(np.nanmedian(dpob[k])), "kNNDM")
                wp = cel["poblacion"].fillna(0).values
                tot = wp.sum() if wp.sum() > 0 else np.nan
                dentro = di.loc[cel["pid"], "dentro_area_aplicabilidad"].values.astype(bool)
                anual.append({"municipio": mu, "metodo": mt, "anio": y,
                              "cabecera_media": cab_m, "cabecera_inferior_90": ci, "cabecera_superior_90": cs,
                              "poblacional_media": pob_m, "poblacional_inferior_90": pi_, "poblacional_superior_90": ps_,
                              "territorial_media": float(np.nanmean(ter[k])),
                              "diferencia_poblacional_menos_cabecera_pct": 100 * (pob_m / cab_m - 1),
                              "cabecera_dias_sobre_limite": int(np.nansum(np.exp(lc[k]) > lim)),
                              "poblacional_dias_sobre_limite": int(np.nansum(pob[k] > lim)),
                              "poblacional_dias_sobre_guia_oms": int(np.nansum(pob[k] > GUIA_OMS[p])),
                              "limite_diario_usado": lim,
                              "fraccion_poblacion_sobre_anual_2254": (float((wp * (mc > lim_a)).sum() / tot)
                                                                      if lim_a else np.nan),
                              "fraccion_poblacion_sobre_anual_oms": (float((wp * (mc > oms_a)).sum() / tot)
                                                                     if oms_a else np.nan),
                              "fraccion_poblacion_en_area_aplicabilidad": float((wp * dentro).sum() / tot),
                              "poblacion_rejilla": float(wp.sum()),
                              "vecina_cabecera_mediana_km": float(np.nanmedian(dc[k])),
                              "vecina_poblacion_mediana_km": float(np.nanmedian(dpob[k])),
                              "DI_cabecera": float(di.loc[g[es_cab]["pid"].values[0], "DI"]),
                              "cabecera_en_area_aplicabilidad": bool(di.loc[g[es_cab]["pid"].values[0],
                                                                         "dentro_area_aplicabilidad"])})
    pd.concat(diario, ignore_index=True).to_csv(os.path.join(salida, f"{p}_municipios_diario.csv.gz"), index=False)
    an = pd.DataFrame(anual)
    an.to_csv(os.path.join(salida, f"{p}_municipios_anual.csv"), index=False)
    # comparación de los cuatro enfoques: {cabecera, media poblacional} x {inverso de la distancia, híbrido}
    comp = []
    for mt in METODOS:
        x = an[an["metodo"] == mt]
        for enf, ds in (("cabecera", "kNNDM_cabeceras"), ("poblacional", "kNNDM")):
            comp.append(pd.DataFrame({"municipio": x["municipio"], "anio": x["anio"], "metodo": mt, "enfoque": enf,
                                      "media": x[f"{enf}_media"], "inferior_90": x[f"{enf}_inferior_90"],
                                      "superior_90": x[f"{enf}_superior_90"],
                                      "dias_sobre_limite": x[f"{enf}_dias_sobre_limite"],
                                      "diseño_de_validacion": ds, "metodo_elegido": eleccion[ds] == mt}))
    comp = pd.concat(comp, ignore_index=True)
    comp.to_csv(os.path.join(salida, f"{p}_comparacion_enfoques.csv"), index=False)
    d = an.groupby(["metodo", "municipio"])["diferencia_poblacional_menos_cabecera_pct"].mean()
    for mt in METODOS:
        if mt in d.index.get_level_values(0):
            v = d.loc[mt]
            log(f"  {mt}: media poblacional frente a cabecera, diferencia mediana {v.median():+.1f} % "
                f"(de {v.min():+.1f} a {v.max():+.1f} % según el municipio)")
    pd.concat(celdas, ignore_index=True).to_csv(os.path.join(salida, f"{p}_celdas_anual.csv.gz"), index=False)
    cab_ok = aoa[aoa["tipo"] == "cabecera"]["dentro_area_aplicabilidad"]
    log(f"  área de aplicabilidad: {int(cab_ok.sum())} de {len(cab_ok)} cabeceras dentro; "
        f"{100 * aoa[aoa['tipo'] == 'celda']['dentro_area_aplicabilidad'].mean():.0f} % de las celdas")
    with open(os.path.join(salida, f"{p}_modelo.json"), "w", encoding="utf-8") as f:
        json.dump({"contaminante": p, "estaciones": S, "pliegues_kNNDM": info, "pliegues_kNNDM_cabeceras": info_cab,
                   "hiperparametros": HGB, "radios_aumento_km": RADIOS_AUMENTO,
                   "metodos": DESCRIPCION, "metodo_elegido": eleccion,
                   "similitud_suelo": {"variables": dat.vars_suelo, "logaritmo": sorted(LOG_SUELO),
                                       "ancho_de_banda_h": dat.h_suelo},
                   "ajuste_suelo": {"alfa_elegido": float(M["ridge"].alfa) if M["ridge"] is not None else None,
                                    "alfas_candidatos": ALFAS_RIDGE + ["sin corrección"],
                                    "intercepto": float(M["ridge"].intercept_) if M["ridge"] is not None else None,
                                    "coeficientes": (dict(zip(M["cols_du"], M["ridge"].coef_.astype(float)))
                                                     if M["ridge"] is not None else None)},
                   "iteraciones_modelo_final": {k: int(M[k].n_iter_) for k in ("hibrido", "hibrido_suelo")},
                   "correccion_duan_por_clase_km": {k: (M[k].smear_ if k.startswith("hib") else M[f"smear_{k}"])
                                                    for k in ("idw", "idw_suelo", "hibrido", "hibrido_suelo")},
                   "variables": {k: M[k].cols_ for k in ("hibrido", "hibrido_suelo")}}, f, ensure_ascii=False,
                  indent=1)
    return resumen
