# V8.3: estimación diaria en los municipios a partir de las estaciones del SVCA

La V8 cambia la unidad de análisis. En lugar de cinco series de distrito, cada estación del SVCA es una
unidad, con sus coordenadas. Para cada contaminante y cada día, el modelo parte de lo que miden ese día las
estaciones vecinas (pesos por el inverso de la distancia al cuadrado) y corrige esa interpolación con lo que
diferencia al lugar de sus vecinas: meteorología, satélite, altitud, población, superficie construida, luces
nocturnas y coberturas. Las covariables se extraen en el punto de cada estación y en la cabecera de cada
municipio, a la misma escala.

- **Contaminantes:** PM2.5, PM10 y NO2 (medias de 24 h) y O3 (MDA8), en µg/m³, 2019-2024.
- **Estaciones:** todas las que miden cada contaminante con al menos 274 días válidos, de Antioquia, Bogotá,
  Boyacá, Magdalena, Santander, Atlántico, Bolívar, Cesar, La Guajira y Cundinamarca, después del control de
  calidad del Protocolo (versión 2). El detalle está en `datos/CONTROL_CALIDAD.json`.
- **Municipios:** los 12 de estudio, en todo el territorio. El modelo estima la cabecera (el píxel de
  100 m con más población) y cada celda de una rejilla que cubre todo el polígono municipal, incluidas las
  celdas del borde (de 1.3 a 3 km de lado, unas 770 celdas). Cada celda se estima en su píxel de 100 m con
  más población (o en un punto interior si no tiene habitantes) y se agrega con su población (GHSL 2020). El resultado principal es
  la media ponderada por población, que es la exposición de la gente; también salen la media territorial y
  la fracción de la población en celdas sobre los valores de referencia anuales.
- **Validación:** pliegues kNNDM, que reproducen la distancia real de los municipios a su estación más
  cercana, en dos versiones (celdas habitadas, para la media poblacional, y cabeceras solas, para el valor
  en la cabecera); además, dejar un departamento fuera y 10 pliegues al azar, para medir el error en todo el rango de
  distancias. Área de aplicabilidad por municipio e intervalos calibrados con los errores de la validación.
- **Seis métodos en los mismos pliegues:**
  1. inverso de la distancia;
  2. inverso de la distancia ponderado además por la similitud de uso del suelo entre el lugar y cada
     estación (coberturas de ESA WorldCover, población y luces);
  3. inverso de la distancia corregido con coeficientes de uso del suelo: una regresión ridge del error
     de la interpolación sobre las diferencias de uso del suelo entre el lugar y sus vecinas, ajustada en
     cada pliegue con las estaciones de entrenamiento;
  4. el híbrido;
  5. el híbrido con la interpolación por suelo;
  6. la media geométrica de los métodos 2 y 5, con pesos iguales fijos.

  El uso del suelo importa porque la mayoría de las estaciones son urbanas y la mayoría de las celdas de
  los municipios no.
- **Elección del método con una regla fijada antes de ver los resultados.** Se prefiere el más simple. Uno
  más complejo se adopta solo si reduce el NMAE en al menos 1 punto aun quitando cualquier grupo de
  estaciones (grupos a menos de 20 km), con un intervalo del 95 % por remuestreo de esos grupos por debajo
  de cero. Además:
  - la ponderación por similitud debe superar a un placebo (el mismo uso del suelo permutado entre
    estaciones);
  - el ajuste por coeficientes debe superar a 19 repeticiones completas con el uso del suelo permutado
    (prueba de permutación, p ≤ 0.05).

  Todos los métodos quedan en los resultados.
- **Diagnóstico del error según el uso del suelo:** relación entre el error de cada estación en la
  validación y su uso del suelo, error por clase de urbanización junto con la fracción de la población de
  los municipios en cada clase, coeficientes del ajuste con su intervalo e importancia por grupos de
  variables.
- **Referencias de comparación en los mismos pliegues:** estación más cercana y modelo sin vecinas.

No necesita tarjeta gráfica. El modelo de Gregori (V7.1) no se usa aquí; sus resultados quedan como
comparación.

## Orden de los pasos

**Para dejar el equipo trabajando solo** (lo recomendado): después de la prueba de acceso a Earth Engine,
un solo comando hace todo lo demás.

```
python correr_v8.py --gee --prueba      (una vez: prueba de acceso a Earth Engine, unos minutos)
python correr_v8.py --todo              (todo lo demás, sin intervención: de 6 a 11 horas)
```

`--todo` extrae las covariables y luego corre el modelo completo. Mientras trabaja:

- deja en la carpeta del paquete el archivo `ESTADO.txt` (en qué etapa va, el último avance y la hora), el
  registro completo `REGISTRO_TODO.txt` y la carpeta `resultados\`; si hay un NAS configurado (paso 3),
  los copia también allí cada 10 minutos, en una subcarpeta `corrida_AAAAMMDD_HHMM\`;
- si Earth Engine falla, espera 30 minutos y reintenta solo (hasta 8 veces), sin repetir lo ya extraído;
- evita que el equipo se suspenda mientras corre.

Al terminar, `ESTADO.txt` dice `TERMINADO` (y, con NAS, los resultados quedan verificados allí). Si dice `FALLÓ`,
trae el motivo. Si el equipo se reinició (por ejemplo por Windows Update, que esto no puede impedir), basta
volver a correr `python correr_v8.py --todo`: sigue donde quedó, conserva las covariables ya extraídas y los
contaminantes ya terminados (si el código y los datos no cambiaron) y, con NAS, abre allí una carpeta nueva.

Antes de dejarlo solo conviene desactivar en Windows los reinicios automáticos por actualizaciones durante
esas horas (Configuración → Windows Update → Pausar actualizaciones).

**Paso a paso** (lo mismo, en comandos separados):

| Paso | Comando | Qué hace | Tiempo |
|---|---|---|---|
| 1 | `python correr_v8.py --gee --prueba` | Prueba de acceso a Earth Engine | minutos |
| 2 | `python correr_v8.py --gee` | Extracción completa de covariables (crea `gee/dinamicas.csv`) | 3-6 h |
| 3 | `python correr_v8.py --prueba` | Prueba corta del modelo (y de la copia al NAS, si está configurado) | minutos |
| 4 | `python correr_v8.py` | Corrida completa del modelo | 3-5 h |

Si el paso 3 o el 4 dicen `faltan las covariables de GEE`, el paso 2 no ha terminado.

## Contenido

```
V8_estaciones/
├── LEEME.md               este archivo
├── instalar.bat           instalación sin Anaconda (crea .venv)
├── requirements.txt       paquetes y versiones para instalar.bat
├── environment.yml        entorno de Anaconda
├── correr_v8.py           el único archivo que se ejecuta
├── v8_gee.py              extracción de covariables en Google Earth Engine
├── v8_modelo.py           modelo, validación y estimaciones
├── datos/
│   ├── CONTROL_CALIDAD.json   resultado del control y huellas de los archivos
│   ├── estaciones.csv         estaciones con coordenadas y días válidos por contaminante
│   ├── observaciones_diarias.csv.gz
│   └── municipios.geojson     polígonos de los 12 municipios
├── gee/                   se crea en el paso 2
└── resultados/            se crea en el paso 4
```

## 1. Copiar la carpeta y preparar el entorno

Copiar `V8_estaciones` a un **disco local** (no OneDrive ni red). Hacen falta 10 GB libres.

Hay dos formas de instalar, una sola vez. Las dos dejan las mismas versiones de los paquetes.

**A. Sin Anaconda (Python 3.13 de la Microsoft Store o de python.org).** Doble clic en `instalar.bat`. Crea
la carpeta `.venv` con los paquetes de `requirements.txt` y al final dice `Instalacion lista`. Si la red de
la institución bloquea la descarga, se copia la carpeta `ruedas` (los paquetes ya descargados, que se
entregan aparte) dentro de `V8_estaciones` y se vuelve a ejecutar `instalar.bat`, que instala sin internet.

Después, todos los comandos de este LEEME se escriben en el **Símbolo del sistema** (cmd), dentro de la
carpeta, con `.venv\Scripts\python` en lugar de `python`. Por ejemplo:

```
cd /d C:\V8_estaciones
.venv\Scripts\python correr_v8.py --gee --prueba
.venv\Scripts\python correr_v8.py --todo
```

**B. Con Anaconda.** En Anaconda Prompt, dentro de la carpeta:

```
conda env create -f environment.yml
conda activate v8_estaciones
```

y los comandos se escriben con `python`, como aparecen en el resto de este LEEME.

## 2. Covariables de Google Earth Engine

Hace falta una cuenta de Google con acceso a Earth Engine en el proyecto `amazing-codex-465023-e9` (el
mismo de `GEE_Data_Download.py`). Si se usa otro proyecto, antes de correr:
`set V8_PROYECTO_GEE=nombre-del-proyecto`.

Primero una prueba de acceso (un mes y cinco puntos, unos minutos; la primera vez abre el navegador para
autenticarse):

```
python correr_v8.py --gee --prueba
```

Debe terminar con `Listo. Covariables en ...\gee_prueba`. Después, la extracción completa:

```
python correr_v8.py --gee
```

Calcula primero las cabeceras y la rejilla (población y área de cada celda) y luego unas 2500 consultas a
Earth Engine para unos 970 puntos (estaciones, cabeceras y celdas). Puede tardar de tres a seis horas. Cada consulta se guarda en
`gee/_cache`: si se interrumpe, el mismo comando sigue donde quedó. Si una consulta falla varias veces, el
mensaje lo dice y basta con volver a correr el mismo comando. La altura de la capa límite es opcional: si su
colección no responde, aparece un aviso y el modelo sigue sin ella.

Earth Engine limita las consultas simultáneas. Si aparece `Earth Engine pide esperar (...)`, no hay que
hacer nada: el programa espera (de 30 s a 10 min) y reintenta solo.

## 3. Copia al NAS (opcional)

**Sin configurar nada, no hay copia:** los resultados quedan en `resultados\` dentro de la carpeta del
paquete, y el programa lo avisa al arrancar (`Sin copia al NAS`). Así corre en cualquier equipo.

Para copiar el avance y los resultados a un NAS o a otra carpeta de red, se escribe la ruta en la línea
`NAS = r""` de la sección CONFIGURACIÓN, al inicio de `correr_v8.py`. En el equipo de Chile:

```
NAS = r"Z:\Environmental Justice\V8_estaciones"
```

También se puede dar en una sola corrida con `--nas "RUTA"`. Con una ruta configurada:

- **Antes de empezar,** la corrida comprueba que se pueda escribir allí. Si la unidad no está conectada, no
  arranca, para no perder horas de cálculo (`--sin-nas` la ignora en esa corrida).
- **Durante la corrida,** copia el avance (`REGISTRO.txt` y los archivos ya terminados) cada 10 minutos y al
  terminar cada contaminante, para revisarlo sin entrar al equipo.
- **Al terminar,** copia `resultados/` y `gee/` (sin `_cache`) y comprueba cada archivo con su huella
  SHA-256. Debe aparecer `Copiado al NAS y verificado archivo por archivo`.
- Cada corrida queda en su propia subcarpeta con fecha y hora; ninguna reemplaza a otra.
- Si el NAS no responde al final, se reintenta tres veces; los resultados quedan completos en el equipo y se
  copian después con `python correr_v8.py --copiar-nas`.

## 4. Prueba corta del modelo (unos minutos)

```
python correr_v8.py --prueba
```

Primero aparece `Control de calidad de los datos: APROBADO`. Debe terminar con `TERMINADO` y crear
`resultados_prueba/`, que no sirve como resultado. Si hay NAS configurado, también aparece `NAS comprobado`
y la prueba se copia allí en `prueba_AAAAMMDD_HHMM\`, así se comprueba el NAS antes de la corrida larga.

## 5. Corrida completa

```
python correr_v8.py
```

Con 20 núcleos debería tardar entre tres y cinco horas. El avance se ve en pantalla y queda en
`resultados/REGISTRO.txt`. Si se interrumpe, se puede correr un solo contaminante:
`python correr_v8.py --contaminante pm25` (pm25, pm10, no2, o3).

## 6. Resultados

En `resultados/`, por contaminante:

| Archivo | Qué contiene |
|---|---|
| `<c>_validacion_resumen.csv` | Medianas por estación de R², r, r de anomalías, error medio y NMAE, por diseño y método |
| `<c>_validacion_por_estacion.csv` | Las mismas métricas por estación de prueba |
| `<c>_error_por_distancia.csv` | Error según la distancia a la estación más cercana |
| `<c>_error_media_anual_y_excedencias.csv` | Error de la media anual y de los días sobre el límite en las estaciones de prueba |
| `<c>_intervalos_conformes.csv` | Intervalos del 90 % por clase de distancia y método, con la cobertura lograda en validación cruzada (si no llega al 90 % con cuantiles 0.5-99.5 %, queda anotado) |
| `<c>_area_aplicabilidad.csv` | Índice de disimilitud de cada cabecera y celda y si está dentro del área de aplicabilidad |
| `<c>_municipios_diario.csv.gz` | Por municipio, método y día: valor en la cabecera, media ponderada por población y media territorial, con intervalos del 90 % para la cabecera y la media poblacional |
| `<c>_municipios_anual.csv` | Por municipio, método y año: medias de la cabecera, poblacional y territorial con intervalos (del error medido de la media anual en validación), días sobre el límite diario de la Res. 2254 y sobre la guía de la OMS, fracción de la población sobre los valores anuales de la Res. 2254 y de la OMS, y fracción de la población dentro del área de aplicabilidad |
| `<c>_eleccion_metodo.csv` | Diferencias de NMAE entre métodos con su intervalo del 95 % y sin el peor grupo, el placebo de la similitud, la prueba de permutación del ajuste y el método elegido en cada diseño kNNDM |
| `<c>_comparacion_enfoques.csv` | Por municipio y año, los doce enfoques lado a lado (cabecera o media poblacional, con cada uno de los seis métodos), cada uno con su intervalo, sus días sobre el límite y si es el método elegido |
| `<c>_error_segun_suelo.csv` | Correlación de rangos entre el error de cada estación en la validación (error medio y NMAE) y cada variable de uso del suelo, por método, con intervalo del 95 % |
| `<c>_error_por_urbanizacion.csv` | Error por clase de urbanización de las estaciones (terciles de la fracción construida en 1 km) y fracción de la población de los municipios y número de cabeceras en cada clase |
| `<c>_coeficientes_suelo.csv` | Coeficientes del ajuste por uso del suelo: % de cambio de la concentración por una desviación estándar más que las vecinas, con intervalo del 95 % y la penalización elegida (`inf` = sin corrección) |
| `<c>_coeficientes_suelo_por_pliegue.csv` y `<c>_permutaciones_ajuste_suelo.csv.gz` | Coeficientes de cada pliegue y resultado de cada permutación |
| `<c>_importancia_grupos.csv` | Importancia por permutación conjunta de cada grupo de variables (vecinas, uso del suelo, relieve, satélite, meteorología, calendario) en todos los pliegues kNNDM |
| `<c>_celdas_anual.csv.gz` | Media anual de cada celda con su población, área, distancia a la estación más cercana y área de aplicabilidad (para mapas) |
| `<c>_importancia.csv` | Importancia de cada variable por permutación |
| `<c>_modelo.json` | Configuración, pliegues y variables |

Y `VALIDACION_RESUMEN.csv` con los cuatro contaminantes. Las estimaciones de los municipios salen con los
seis métodos; el que se usa en el artículo es el que elige la regla con la validación kNNDM, que es la que
reproduce la distancia de los municipios a sus estaciones, y los demás quedan como análisis de
sensibilidad.

Al terminar, `resultados/` y `gee/` (sin `_cache`) se comprimen y se suben a OneDrive en `archive/` (si hay
NAS configurado, ya están copiados allí).

## Si algo falla

- `NO SE PUEDE CORRER`: el mensaje dice qué falta o qué cambió. **No abrir ni guardar los CSV de `datos/`
  con Excel**: si un archivo cambia, la corrida no arranca.
- Error de autenticación de Earth Engine: correr `earthengine authenticate` y repetir.
- `no se puede escribir en el NAS`: revisar que la unidad esté conectada en el Explorador de archivos, o
  dejar `NAS = r""` en `correr_v8.py` para correr sin copia.
- `NO SE PUDO COPIAR AL NAS`: los resultados están completos en `resultados/`; cuando el NAS responda,
  `python correr_v8.py --copiar-nas`.

## Cambios de la V8.3 (14-nov-2026), después de revisar la corrida V8.2

- **Rejilla.** La V8.2 solo conservaba las celdas con el centro dentro del polígono y perdía las franjas del
  borde (6-14 % del área). En Fundación y Pueblo Viejo eso dejaba por fuera el casco urbano, así que su media
  poblacional no representaba a la gente. Ahora entran todas las celdas que tocan el polígono (cobertura del
  99.5-100 % del área) y cada una se estima donde vive la gente. La rejilla y las covariables fijas se
  recalculan solas; las de la V8.2 quedan en `_to_delete`.
- **Intervalos.** Una clase de distancia con menos de 8 estaciones (intervalos diarios) o de 20
  estaciones-año (media anual) toma también las clases vecinas. En la V8.2, con 2 a 5 estaciones-año, el
  intervalo de la media anual de O3 quedaba en algunos municipios por encima de la propia estimación.
- **Caché de Earth Engine.** Cada archivo lleva la huella de sus puntos, para que un cambio de puntos no
  reutilice consultas de otros. Por eso la V8.3 vuelve a extraer todas las covariables dinámicas.
- Los valores en la cabecera y la validación en las estaciones no dependen de la rejilla.
- **Rendimiento.** La construcción de las filas de cada estación y de cada punto de los municipios, que
  corría en un solo núcleo, ahora usa todos los núcleos (en un pliegue de PM2.5, 1.7 veces más rápida con 2
  núcleos), y las predicciones de cada municipio se hacen en un solo lote. Los resultados son idénticos a los
  de la versión anterior (comprobado archivo por archivo). El modelo de árboles ya usaba todos los núcleos.

## Verificación hecha antes de entregar

- Los datos pasaron el control de calidad (APROBADO) y sus huellas están en `datos/CONTROL_CALIDAD.json`.
- El modelo corrió de principio a fin en la nube con covariables simuladas en lugar de las de Earth Engine,
  con la rejilla de los 12 municipios (las métricas de esa prueba no sirven como resultado). La rejilla se
  genera sin Earth Engine y se comprobó; la población de cada celda sí sale de Earth Engine.
- Con usos del suelo aleatorios (los de la prueba), ninguno de los métodos con suelo fue elegido en
  ningún contaminante: el placebo, la prueba de permutación y la condición de quitar un grupo los
  descartaron. La prueba de permutación y la validación dan la misma diferencia de NMAE, calculada por dos
  caminos distintos.
- La copia al NAS se probó con una carpeta local: copia periódica durante la corrida, copia final verificada
  archivo por archivo, copia posterior con `--copiar-nas`, y una ruta no escribible (la corrida se detiene
  antes de empezar).
- La extracción de Earth Engine no se pudo probar en la nube, porque necesita la cuenta del proyecto; por
  eso el paso 2 empieza con una prueba de acceso.
