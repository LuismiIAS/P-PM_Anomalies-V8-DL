@echo off
rem Instala el entorno de la V8 con el Python de Windows (Microsoft Store o python.org), sin Anaconda.
rem Doble clic sobre este archivo, o en el Simbolo del sistema dentro de la carpeta: instalar.bat
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo No se encuentra Python. Instale Python 3.13 desde la Microsoft Store y vuelva a intentarlo.
  pause
  exit /b 1
)
python -c "import sys; assert sys.version_info[:2]==(3,13), sys.version" || (
  echo Hace falta Python 3.13.
  pause
  exit /b 1
)
if not exist .venv (
  echo Creando el entorno en la carpeta .venv ...
  python -m venv .venv || (echo No se pudo crear el entorno. & pause & exit /b 1)
)
if exist ruedas (
  echo Instalando desde la carpeta ruedas, sin internet ...
  .venv\Scripts\python -m pip install --no-index --find-links ruedas -r requirements.txt || (echo Fallo la instalacion. & pause & exit /b 1)
) else (
  echo Instalando desde internet ...
  .venv\Scripts\python -m pip install --upgrade pip
  .venv\Scripts\python -m pip install -r requirements.txt || (
    echo.
    echo Fallo la instalacion desde internet. Si la red de la institucion bloquea pip, copie la carpeta
    echo "ruedas" dentro de esta carpeta y vuelva a ejecutar instalar.bat.
    pause
    exit /b 1
  )
)
.venv\Scripts\python -c "import numpy, pandas, scipy, sklearn, ee; print('Instalacion lista: numpy', numpy.__version__, '| pandas', pandas.__version__, '| scikit-learn', sklearn.__version__)"
echo.
echo Para correr, en el Simbolo del sistema dentro de esta carpeta:
echo     .venv\Scripts\python correr_v8.py --gee --prueba
echo     .venv\Scripts\python correr_v8.py --todo
pause
