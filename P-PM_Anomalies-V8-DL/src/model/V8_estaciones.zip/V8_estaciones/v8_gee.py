"""
v8_gee.py

Extrae de Google Earth Engine las covariables del modelo V8 en el punto de cada estación del SVCA y en la
cabecera de cada municipio de estudio, a la misma escala en los dos casos (la causa principal del mal
desempeño de la V7.1 fue entrenar con promedios de una caja departamental y predecir en otro soporte).

Diarias, 2019-01-01 a 2024-12-31
  ERA5-Land (ECMWF/ERA5_LAND/DAILY_AGGR), media en 5 km: temperatura (media, mínima, máxima), punto de
      rocío, viento u y v a 10 m, presión, precipitación y radiación solar diarias.
  ERA5 horario (ECMWF/ERA5/HOURLY), altura de la capa límite: media y máxima diarias. Opcional: si la
      colección no responde, se omite y el modelo sigue sin ella.
  MERRA-2 aerosoles (NASA/GSFC/MERRA/aer/2), punto: AOD total y PM2.5 de superficie del reanálisis
      (polvo + sal marina finos + carbono negro + 1.4 x carbono orgánico + 1.375 x sulfato), que sirve de
      referencia geofísica lejos de las estaciones.
  MAIAC (MODIS/061/MCD19A2_GRANULES), AOD a 550 nm de 1 km, media en 3 km.
  TROPOMI (COPERNICUS/S5P/OFFL), media en 5 km: NO2 troposférico (fracción de nubes < 0.3), O3 total y CO.
Fijas
  Altitud SRTM (punto y diferencia con la media en 5 km), población GHSL 2020 y superficie construida
  GHSL 2020 en 1 y 5 km, luces nocturnas VIIRS 2019-2024 en 1 y 5 km, NDVI MODIS 2019-2024 en 1 km y
  fracciones de cobertura ESA WorldCover en 1 y 5 km.
Cabecera de cada municipio
  El píxel de 100 m con más población (GHSL 2020) dentro del polígono municipal. Se puede reemplazar por
  coordenadas propias en datos/municipios_puntos_manual.csv (columnas municipio, lat, lon).
Rejilla de cada municipio
  Celdas cuadradas que cubren el polígono municipal, de lado min(3 km, raíz(área/25)), para que cada
  municipio tenga al menos unas 25 celdas; entra la celda cuyo centro cae dentro del polígono. Para cada
  celda se calcula su población (GHSL 2020, suma de píxeles de 100 m dentro de la celda y del municipio) y su
  área dentro del municipio. Con esas celdas el modelo estima la exposición de toda la población del
  municipio (media ponderada por población), no solo la de la cabecera.

Los faltantes del satélite (nubes) quedan como faltantes: el modelo de árboles los trata sin rellenarlos.
Cada consulta se guarda en gee/_cache y la extracción se puede interrumpir y retomar sin repetir trabajo.
"""
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd

INICIO, FIN = "2019-01-01", "2025-01-01"          # FIN exclusivo
LOTE = 150                                        # puntos por consulta (límite de 5000 elementos de GEE)
HILOS = 4                                         # consultas simultáneas (Earth Engine limita las agregaciones)
REINTENTOS = 6
ESPERAS = [30, 60, 120, 240, 480, 600]            # s, crecientes: los límites de Earth Engine son temporales
TEMPORALES = ("too many concurrent", "rate limit", "quota", "429", "too many requests", "temporarily",
              "unavailable", "internal error", "connection", "503", "502")


def es_temporal(e):
    return any(t in str(e).lower() for t in TEMPORALES)


def con_reintentos(f, etiqueta=""):
    """Ejecuta f(); si Earth Engine responde con un límite temporal, espera y reintenta."""
    for intento, espera in enumerate(ESPERAS, 1):
        try:
            return f()
        except Exception as e:
            if not es_temporal(e) or intento == len(ESPERAS):
                raise
            print(f"  Earth Engine pide esperar ({str(e)[:80]}); {etiqueta} reintento {intento} en {espera} s",
                  flush=True)
            time.sleep(espera)

ERA5L_BANDAS = {
    "temperature_2m": "t2m", "temperature_2m_min": "t2m_min", "temperature_2m_max": "t2m_max",
    "dewpoint_temperature_2m": "d2m", "u_component_of_wind_10m": "u10", "v_component_of_wind_10m": "v10",
    "surface_pressure": "sp", "total_precipitation_sum": "tp", "surface_solar_radiation_downwards_sum": "ssrd",
}
WORLDCOVER = {10: "arboles", 20: "arbustos", 30: "pastos", 40: "cultivos", 50: "construido", 60: "suelo_desnudo",
              80: "agua", 90: "humedal"}


def iniciar(proyecto):
    import ee
    try:
        ee.Initialize(project=proyecto)
    except Exception:
        ee.Authenticate()
        ee.Initialize(project=proyecto)
    return ee


# ── Productos diarios: cada uno devuelve (imagen del día o None, bandas de salida, escala, radio) ──
def productos(ee):
    colombia = ee.Geometry.Rectangle([-79.5, -4.5, -66.5, 13.5])

    def relleno(c, bandas):
        """Deja solo las imágenes que tocan Colombia y agrega una imagen con las mismas bandas, toda
        enmascarada: la media y el máximo la ignoran, y un día sin imágenes da faltante en lugar de error
        (sin consultar cuántas hay)."""
        vacia = ee.Image.constant([0] * len(bandas)).rename(bandas).toFloat().updateMask(ee.Image(0))
        return c.filterBounds(colombia).map(lambda i: i.toFloat()).merge(ee.ImageCollection([vacia]))

    def era5l(d0, d1):
        c = ee.ImageCollection("ECMWF/ERA5_LAND/DAILY_AGGR").filterDate(d0, d1).select(list(ERA5L_BANDAS),
                                                                                         list(ERA5L_BANDAS.values()))
        c = relleno(c, list(ERA5L_BANDAS.values()))
        return c, c.mean()

    def blh(d0, d1):
        c = relleno(ee.ImageCollection("ECMWF/ERA5/HOURLY").filterDate(d0, d1).select("boundary_layer_height"),
                    ["boundary_layer_height"])
        img = c.mean().rename("blh_media").addBands(c.max().rename("blh_max"))
        return c, img

    def merra(d0, d1):
        bm = ["TOTEXTTAU", "DUSMASS25", "SSSMASS25", "BCSMASS", "OCSMASS", "SO4SMASS"]
        c = relleno(ee.ImageCollection("NASA/GSFC/MERRA/aer/2").filterDate(d0, d1).select(bm), bm)
        m = c.mean()
        pm = (m.select("DUSMASS25").add(m.select("SSSMASS25")).add(m.select("BCSMASS"))
              .add(m.select("OCSMASS").multiply(1.4)).add(m.select("SO4SMASS").multiply(1.375))
              .multiply(1e9).rename("pm25_merra2"))
        return c, m.select(["TOTEXTTAU"], ["aod_merra2"]).addBands(pm)

    def maiac(d0, d1):
        c = relleno(ee.ImageCollection("MODIS/061/MCD19A2_GRANULES").filterDate(d0, d1).select("Optical_Depth_055"),
                    ["Optical_Depth_055"])
        return c, c.mean().multiply(0.001).rename("aod_maiac")

    def no2(d0, d1):
        c = (ee.ImageCollection("COPERNICUS/S5P/OFFL/L3_NO2").filterDate(d0, d1)
             .map(lambda i: i.select("tropospheric_NO2_column_number_density")
                  .updateMask(i.select("cloud_fraction").lt(0.3))))
        c = relleno(c, ["tropospheric_NO2_column_number_density"])
        return c, c.mean().rename("no2_tropomi")

    def o3(d0, d1):
        c = relleno(ee.ImageCollection("COPERNICUS/S5P/OFFL/L3_O3").filterDate(d0, d1)
                    .select("O3_column_number_density"), ["O3_column_number_density"])
        return c, c.mean().rename("o3_tropomi")

    def co(d0, d1):
        c = relleno(ee.ImageCollection("COPERNICUS/S5P/OFFL/L3_CO").filterDate(d0, d1)
                    .select("CO_column_number_density"), ["CO_column_number_density"])
        return c, c.mean().rename("co_tropomi")

    return {
        # nombre: (función, bandas de salida, escala m, radio m, obligatorio)
        "era5land": (era5l, list(ERA5L_BANDAS.values()), 1000, 5000, True),
        "blh": (blh, ["blh_media", "blh_max"], 5000, 0, False),
        "merra2": (merra, ["aod_merra2", "pm25_merra2"], 10000, 0, True),
        "maiac": (maiac, ["aod_maiac"], 1000, 3000, True),
        "no2": (no2, ["no2_tropomi"], 1000, 5000, True),
        "o3": (o3, ["o3_tropomi"], 1000, 5000, True),
        "co": (co, ["co_tropomi"], 1000, 5000, True),
    }


def coleccion_puntos(ee, pts, radio):
    feats = []
    for r in pts.itertuples():
        g = ee.Geometry.Point([float(r.lon), float(r.lat)])
        if radio > 0:
            g = g.buffer(radio)
        feats.append(ee.Feature(g, {"pid": str(r.pid)}))
    return ee.FeatureCollection(feats)


def filas_de(res, dias, bandas):
    """Pasa la respuesta de Earth Engine (bandas d<AAAAMMDD>_<variable>) a una fila por punto y día."""
    filas = []
    for f in res["features"]:
        pr = f["properties"]
        for d in dias:
            fila = {"pid": pr.get("pid"), "date": d.strftime("%Y-%m-%d")}
            for b in bandas:
                fila[b] = pr.get(f"d{d:%Y%m%d}_{b}")
            filas.append(fila)
    return pd.DataFrame(filas).reindex(columns=["pid", "date"] + bandas)


def consulta_mes(ee, prod, pts, mes, partes=1):
    """Una consulta: todos los días de un mes para un lote de puntos. Los días se apilan en una sola imagen
    (bandas d<AAAAMMDD>_<variable>) y se reducen de una vez, con una sola agregación por consulta; reducir
    día por día dentro de la misma consulta excede el límite de agregaciones simultáneas de Earth Engine.
    Con partes > 1 el mes se divide en tramos de días, cada uno en su propia consulta."""
    fn, bandas, escala, radio, _ = prod
    fc = coleccion_puntos(ee, pts, radio)
    m0 = pd.Timestamp(mes)
    m1 = min(m0 + pd.offsets.MonthBegin(1), pd.Timestamp(FIN))
    todos = list(pd.date_range(m0, m1 - pd.Timedelta(days=1)))
    tablas = []
    for k in range(partes):
        dias = todos[k * len(todos) // partes:(k + 1) * len(todos) // partes]
        if not dias:
            continue
        capas = []
        for d in dias:
            e0 = ee.Date(d.strftime("%Y-%m-%d"))
            _, img = fn(e0, e0.advance(1, "day"))
            capas.append(ee.Image(img).select(bandas).rename([f"d{d:%Y%m%d}_{b}" for b in bandas]))
        res = ee.Image.cat(capas).reduceRegions(collection=fc, reducer=ee.Reducer.mean(), scale=escala,
                                                 tileScale=4).getInfo()
        tablas.append(filas_de(res, dias, bandas))
    return pd.concat(tablas, ignore_index=True)


def extraer_dinamicas(ee, pts, salida, cache, prueba=False):
    os.makedirs(cache, exist_ok=True)
    prods = productos(ee)
    meses = pd.date_range(INICIO, pd.Timestamp(FIN) - pd.Timedelta(days=1), freq="MS")
    if prueba:
        meses = meses[:1]
    lotes = [pts.iloc[i:i + LOTE] for i in range(0, len(pts), LOTE)]
    # el nombre de cada archivo del caché lleva la huella de los puntos del lote: si los puntos cambian, no se
    # reutiliza por error un archivo de otros puntos
    import hashlib
    huellas = [hashlib.sha1("|".join(f"{r.pid},{float(r.lat):.6f},{float(r.lon):.6f}" for r in l.itertuples())
                              .encode()).hexdigest()[:12] for l in lotes]
    omitidos = set()
    # comprobación previa: una consulta pequeña por producto, para no gastar horas en uno que no responde
    for n, prod in prods.items():
        try:
            con_reintentos(lambda: consulta_mes(ee, prod, pts.iloc[:3], meses[0]), f"comprobación de {n}:")
            print(f"  {n}: responde", flush=True)
        except Exception as e:
            if prod[4]:
                print(f"\nNO SE PUEDE EXTRAER {n}: {str(e)[:300]}")
                print("Revise la conexión y el acceso a Earth Engine y vuelva a correr el mismo comando.")
                sys.exit(1)
            print(f"AVISO: {n} no responde ({str(e)[:150]}). El modelo sigue sin esa variable.")
            omitidos.add(n)
    trabajos = [(n, k, m) for n in prods if n not in omitidos for k in range(len(lotes)) for m in meses]

    def hacer(n, k, m):
        f = os.path.join(cache, f"{n}_{huellas[k]}_{m:%Y%m}.csv")
        if os.path.exists(f):
            return n, None
        ultimo = None
        for intento in range(REINTENTOS):
            partes = 1 if intento == 0 else 4            # si el mes entero es muy pesado, en cuatro tramos
            try:
                t = con_reintentos(lambda: consulta_mes(ee, prods[n], lotes[k], m, partes), f"{n} {m:%Y-%m}:")
                t.to_csv(f + ".tmp", index=False)
                os.replace(f + ".tmp", f)                # el caché solo guarda consultas completas
                return n, None
            except Exception as e:                       # tiempo de espera largo o colección inexistente
                ultimo = e
                time.sleep(ESPERAS[min(intento, len(ESPERAS) - 1)])
        return n, f"{n} {m:%Y-%m} lote {k}: {str(ultimo)[:200]}"

    errores = []
    with ThreadPoolExecutor(HILOS) as ex:
        futs = [ex.submit(hacer, *t) for t in trabajos]
        for i, fu in enumerate(as_completed(futs), 1):
            n, err = fu.result()
            if err:
                errores.append(err)
            if i % 50 == 0 or i == len(futs):
                print(f"  dinámicas: {i}/{len(futs)} consultas", flush=True)
    for n, (_, _, _, _, oblig) in prods.items():
        e = [x for x in errores if x.startswith(n + " ")]
        if e and oblig:
            print(f"\nNO SE PUDO EXTRAER {n} ({len(e)} consultas fallidas). Primer error:\n  {e[0]}")
            print("Vuelva a correr el mismo comando: solo repite lo que falta.")
            sys.exit(1)
        if e:
            print(f"AVISO: {n} no se pudo extraer ({e[0][:150]}). El modelo sigue sin esa variable.")
            omitidos.add(n)
    # unir por producto y luego todos
    tablas = []
    for n in prods:
        if n in omitidos:
            continue
        fs = [os.path.join(cache, f"{n}_{huellas[k]}_{m:%Y%m}.csv") for k in range(len(lotes)) for m in meses]
        t = pd.concat([pd.read_csv(f, dtype={"pid": str}) for f in fs if os.path.getsize(f) > 0], ignore_index=True)
        tablas.append(t.groupby(["pid", "date"]).mean(numeric_only=True))
    out = pd.concat(tablas, axis=1).reset_index()
    out.to_csv(salida, index=False)
    print(f"  dinámicas guardadas: {salida} ({len(out)} filas, {out['pid'].nunique()} puntos)")


def extraer_fijas(ee, pts, salida):
    srtm = ee.Image("USGS/SRTMGL1_003").select("elevation")
    pop = ee.Image("JRC/GHSL/P2023A/GHS_POP/2020").select("population_count")
    built = ee.Image("JRC/GHSL/P2023A/GHS_BUILT_S/2020").select("built_surface")
    viirs = (ee.ImageCollection("NOAA/VIIRS/DNB/MONTHLY_V1/VCMSLCFG").filterDate(INICIO, FIN)
             .select("avg_rad").mean())
    ndvi = (ee.ImageCollection("MODIS/061/MOD13A2").filterDate(INICIO, FIN).select("NDVI").mean()
            .multiply(0.0001))
    wc = ee.ImageCollection("ESA/WorldCover/v200").first().select("Map")
    filas = []
    for i in range(0, len(pts), LOTE):
        lote = pts.iloc[i:i + LOTE]
        res = {r.pid: {"pid": r.pid} for r in lote.itertuples()}
        for radio in (0, 1000, 5000):
            fc = coleccion_puntos(ee, lote, radio)
            if radio == 0:
                imgs = [(srtm.rename("altitud"), ee.Reducer.mean(), 30)]
            else:
                k = f"{radio // 1000}km"
                imgs = [(pop.rename(f"poblacion_{k}"), ee.Reducer.sum(), 100),
                        (built.rename(f"construido_m2_{k}"), ee.Reducer.sum(), 100),
                        (viirs.rename(f"luces_{k}"), ee.Reducer.mean(), 500)]
                if radio == 1000:
                    imgs.append((ndvi.rename("ndvi_1km"), ee.Reducer.mean(), 1000))
                if radio == 5000:
                    imgs.append((srtm.rename("altitud_media_5km"), ee.Reducer.mean(), 90))
            for img, red, esc in imgs:
                nombre = con_reintentos(lambda: img.bandNames().getInfo())[0]
                r = con_reintentos(lambda: img.reduceRegions(collection=fc, reducer=red.setOutputs([nombre]),
                                                             scale=esc).getInfo(), "fijas:")
                for f in r["features"]:
                    res[f["properties"]["pid"]][nombre] = f["properties"].get(nombre)
            if radio > 0:
                k = f"{radio // 1000}km"
                h = con_reintentos(lambda: wc.reduceRegions(
                    collection=fc, reducer=ee.Reducer.frequencyHistogram().setOutputs(["h"]), scale=50).getInfo(),
                    "coberturas:")
                for f in h["features"]:
                    hist = f["properties"].get("h") or {}
                    tot = sum(hist.values()) or 1
                    for cod, nom in WORLDCOVER.items():
                        res[f["properties"]["pid"]][f"frac_{nom}_{k}"] = hist.get(str(cod), 0) / tot
        filas += list(res.values())
        print(f"  fijas: {min(i + LOTE, len(pts))}/{len(pts)} puntos", flush=True)
    t = pd.DataFrame(filas)
    t["desnivel_5km"] = t["altitud"] - t["altitud_media_5km"]
    t.to_csv(salida, index=False)
    print(f"  fijas guardadas: {salida}")


def cabeceras(ee, geojson, manual, salida):
    with open(geojson, encoding="utf-8") as f:
        fc = json.load(f)
    man = pd.read_csv(manual) if os.path.exists(manual) else pd.DataFrame(columns=["municipio", "lat", "lon"])
    pop = ee.Image("JRC/GHSL/P2023A/GHS_POP/2020").select("population_count")
    img = pop.addBands(ee.Image.pixelLonLat())
    filas = []
    for feat in fc["features"]:
        nom = feat["properties"]["municipio"]
        if nom in set(man["municipio"]):
            r = man[man["municipio"] == nom].iloc[0]
            filas.append({"municipio": nom, "lat": r.lat, "lon": r.lon, "metodo": "manual"})
            continue
        g = ee.Geometry(feat["geometry"])
        r = con_reintentos(lambda: img.reduceRegion(ee.Reducer.max(3).setOutputs(["pop", "lon", "lat"]), g,
                                                    scale=100, maxPixels=1e9).getInfo(), "cabeceras:")
        filas.append({"municipio": nom, "lat": r["lat"], "lon": r["lon"],
                      "metodo": "píxel de 100 m con más población (GHSL 2020)"})
    pd.DataFrame(filas).to_csv(salida, index=False)
    print(f"  cabeceras guardadas: {salida}")


# ═══════════════════════════════════════════════════════════════════
# REJILLA MUNICIPAL
# ═══════════════════════════════════════════════════════════════════
def _anillos(geom):
    return [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]


def _dentro(x, y, poligonos):
    """Punto en polígono (par-impar) con huecos, para Polygon y MultiPolygon."""
    def en_anillo(r):
        c = False
        n = len(r)
        for i in range(n):
            x1, y1 = r[i][0], r[i][1]
            x2, y2 = r[(i + 1) % n][0], r[(i + 1) % n][1]
            if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1 + 1e-15) + x1:
                c = not c
        return c
    for p in poligonos:
        if en_anillo(p[0]) and not any(en_anillo(h) for h in p[1:]):
            return True
    return False


def _area_km2(poligonos):
    import math
    tot = 0.0
    for p in poligonos:
        for k, r in enumerate(p):
            lat0 = math.radians(sum(q[1] for q in r) / len(r))
            xs = [6371 * math.radians(q[0]) * math.cos(lat0) for q in r]
            ys = [6371 * math.radians(q[1]) for q in r]
            a = 0.5 * abs(sum(xs[i] * ys[i - 1] - ys[i] * xs[i - 1] for i in range(len(r))))
            tot += a if k == 0 else -a
    return tot


def puntos_rejilla(geojson, muestras=11):
    """Celdas de cada municipio (sin Earth Engine). Entra toda celda que toque el polígono, no solo las de
    centro dentro: así no se pierden las franjas del borde (en Fundación y Pueblo Viejo, el casco urbano).
    Para cada celda se guarda un punto interior a la parte de la celda dentro del municipio (el punto de una
    retícula de muestras x muestras más cercano al centroide de esa parte); Earth Engine lo reemplaza luego
    por el píxel de 100 m con más población cuando la celda tiene habitantes."""
    import math
    with open(geojson, encoding="utf-8") as f:
        fc = json.load(f)
    filas = []
    for feat in fc["features"]:
        nom = feat["properties"]["municipio"]
        pol = _anillos(feat["geometry"])
        area = _area_km2(pol)
        lado = max(1.0, min(3.0, math.sqrt(area / 25)))
        xs = [q[0] for p in pol for q in p[0]]
        ys = [q[1] for p in pol for q in p[0]]
        lat0 = (min(ys) + max(ys)) / 2
        dy = lado / 111.32
        dx = lado / (111.32 * math.cos(math.radians(lat0)))
        vertices = [(q[0], q[1]) for p in pol for q in p[0]]
        k = 0
        y = min(ys) + dy / 2
        while y - dy / 2 < max(ys):
            x = min(xs) + dx / 2
            while x - dx / 2 < max(xs):
                dentro = [(x + dx * (a / (muestras - 1) - 0.5), y + dy * (b / (muestras - 1) - 0.5))
                          for a in range(muestras) for b in range(muestras)]
                dentro = [(px, py) for px, py in dentro if _dentro(px, py, pol)]
                if dentro:
                    cx = sum(p[0] for p in dentro) / len(dentro)
                    cy = sum(p[1] for p in dentro) / len(dentro)
                    px, py = min(dentro, key=lambda p: (p[0] - cx) ** 2 + (p[1] - cy) ** 2)
                    filas.append({"municipio": nom, "pid": f"G_{nom.replace(' ', '_')}_{k:03d}", "lat": py,
                                  "lon": px, "lat_centro": y, "lon_centro": x, "lado_km": lado, "dx": dx, "dy": dy,
                                  "fraccion_muestras_dentro": len(dentro) / muestras ** 2})
                    k += 1
                elif any(abs(vx - x) <= dx / 2 and abs(vy - y) <= dy / 2 for vx, vy in vertices):
                    # la celda toca el polígono solo con una astilla más fina que la retícula: se registra
                    filas.append({"municipio": nom, "pid": f"G_{nom.replace(' ', '_')}_{k:03d}", "lat": None,
                                  "lon": None, "lat_centro": y, "lon_centro": x, "lado_km": lado, "dx": dx,
                                  "dy": dy, "fraccion_muestras_dentro": 0.0})
                    k += 1
                x += dx
            y += dy
    return pd.DataFrame(filas)


def rejilla(ee, geojson, salida):
    """Rejilla con la población y el área de cada celda dentro del municipio, y el punto donde se estima cada
    celda: el píxel de 100 m con más población de la parte de la celda dentro del municipio (donde vive la
    gente) o, en celdas sin habitantes, el punto interior. Las celdas sin área dentro del municipio se
    descartan."""
    pts = puntos_rejilla(geojson)
    with open(geojson, encoding="utf-8") as f:
        geoms = {ft["properties"]["municipio"]: ee.Geometry(ft["geometry"]) for ft in json.load(f)["features"]}
    pop = ee.Image("JRC/GHSL/P2023A/GHS_POP/2020").select("population_count")
    pop_lonlat = pop.addBands(ee.Image.pixelLonLat())
    out = []
    for nom, g in pts.groupby("municipio"):
        feats = []
        for r in g.itertuples():
            celda = ee.Geometry.Rectangle([r.lon_centro - r.dx / 2, r.lat_centro - r.dy / 2,
                                           r.lon_centro + r.dx / 2, r.lat_centro + r.dy / 2])
            geo = celda.intersection(geoms[nom], ee.ErrorMargin(10))
            feats.append(ee.Feature(geo, {"pid": r.pid}).set("area_km2", geo.area(10).divide(1e6)))
        fc = ee.FeatureCollection(feats)
        res = con_reintentos(lambda: pop.reduceRegions(collection=fc, reducer=ee.Reducer.sum().setOutputs(["poblacion"]),
                                                       scale=100).getInfo(), "rejilla:")
        mx = con_reintentos(lambda: pop_lonlat.reduceRegions(
            collection=fc, reducer=ee.Reducer.max(3).setOutputs(["pmax", "lon_max", "lat_max"]), scale=100).getInfo(),
            "rejilla:")
        d = {f["properties"]["pid"]: f["properties"] for f in res["features"]}
        dm = {f["properties"]["pid"]: f["properties"] for f in mx["features"]}
        g = g.copy()
        g["poblacion"] = [d.get(p, {}).get("poblacion") or 0.0 for p in g["pid"]]
        g["area_km2"] = [d.get(p, {}).get("area_km2") or 0.0 for p in g["pid"]]
        lat_max = [dm.get(p, {}).get("lat_max") for p in g["pid"]]
        lon_max = [dm.get(p, {}).get("lon_max") for p in g["pid"]]
        con_pob = [(pb > 0 and la is not None and lo is not None) for pb, la, lo in zip(g["poblacion"], lat_max, lon_max)]
        g["punto"] = ["píxel con más población" if c else "punto interior" for c in con_pob]
        g["lat"] = [la if c else v for c, la, v in zip(con_pob, lat_max, g["lat"])]
        g["lon"] = [lo if c else v for c, lo, v in zip(con_pob, lon_max, g["lon"])]
        sin_area = (g["area_km2"] <= 0.001) | g["lat"].isna()
        g = g[~sin_area]
        out.append(g)
        print(f"  rejilla {nom}: {len(g)} celdas de {g['lado_km'].iloc[0]:.1f} km, área {g['area_km2'].sum():,.1f} km², "
              f"población {g['poblacion'].sum():,.0f}", flush=True)
    pd.concat(out).drop(columns=["dx", "dy"]).to_csv(salida, index=False)
    print(f"  rejilla guardada: {salida}")
